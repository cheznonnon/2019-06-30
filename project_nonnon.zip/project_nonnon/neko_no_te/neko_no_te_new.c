// Neko no Te : New File Tweaker
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




//#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_inputpopup.c"
#include "../nonnon/win32/win_radiobutton.c"
#include "../nonnon/win32/win_separator.c"
#include "../nonnon/win32/win_smallbutton.c"

#include "../nonnon/win32/registry.c"
#include "../nonnon/win32/sysinfo.c"


#include "../nonnon/project/macro.c"




#define H_EXT_LINE     n_nekonote_new_hgui[  0 ]
#define H_EXT_LABEL    n_nekonote_new_hgui[  1 ]
#define H_EXT_BUTTON   n_nekonote_new_hgui[  2 ]
#define H_EXT_TEMPLATE n_nekonote_new_hgui[  3 ]
#define H_EXT_SMLBTN   n_nekonote_new_hgui[  4 ]
#define H_TYP_LINE     n_nekonote_new_hgui[  5 ]
#define H_TYP_NAME     n_nekonote_new_hgui[  6 ]
#define H_TYP_SMLBTN   n_nekonote_new_hgui[  7 ]
#define H_PAD_LINE     n_nekonote_new_hgui[  8 ]
#define GUI_MAX                              9


#define N_NEKONOTE_NEW_HKLM     n_posix_literal( "System" )
#define N_NEKONOTE_NEW_HKCU     n_posix_literal( "User" )
#define N_NEKONOTE_NEW_TEMPLATE n_posix_literal( "Template" )
#define N_NEKONOTE_NEW_NAME     n_posix_literal( "Displayed Name" )




static HWND              n_nekonote_new_hgui[ GUI_MAX ];

static n_posix_char      n_nekonote_new_ext[ N_PATH_MAX ] = N_STRING_EMPTY;
static n_posix_char      n_nekonote_new_typ[ N_PATH_MAX ] = N_STRING_EMPTY;

static n_win_radio       n_nekonote_new_radio_hklm;
static n_win_radio       n_nekonote_new_radio_hkcu;

static n_win_check       n_nekonote_new_check_ext;
static n_win_check       n_nekonote_new_check_typ;

static n_win_txtbox      n_nekonote_new_input_ext;
static n_win_txtbox      n_nekonote_new_input_typ;

static n_win_smallbutton n_nekonote_new_smallbutton_ext;
static n_win_smallbutton n_nekonote_new_smallbutton_typ;

static bool              n_nekonote_new_is_system = true;//false;




void
n_nekonote_new_error( void )
{

	n_project_dialog_info
	(
		GetParent( H_EXT_LINE ),
		n_posix_literal( "Administrator rights are needed." )
	);


	return;
}

void
n_nekonote_new_nullfile_init( HKEY *hive, n_posix_char *path, n_posix_char *lval )
{

	if ( n_nekonote_new_is_system )
	{
		(*hive) = HKEY_LOCAL_MACHINE;
	} else {
		(*hive) = HKEY_CURRENT_USER;
	}

	n_posix_sprintf_literal( path, "Software\\Classes\\%s\\ShellNew", n_nekonote_new_ext );

	n_posix_sprintf_literal( lval, "%s", n_posix_literal( "NullFile" ) );


	return;
}

void
n_nekonote_new_nullfile_addremove( void )
{

	HKEY         hive;
	n_posix_char path[ N_PATH_MAX ];
	n_posix_char lval[ N_PATH_MAX ];

	n_nekonote_new_nullfile_init( &hive, path, lval );


	DWORD ret = 0;

	if ( n_registry_is_exist( hive, path, lval ) )
	{
		ret = n_registry_delete_value( hive, path, lval );
	} else {
		ret = n_registry_write( hive, path, lval, REG_SZ, N_STRING_EMPTY, 0 );
	}

	if ( ret ) { n_nekonote_new_error(); }


	return;
}

void
n_nekonote_new_filename_init( HKEY *hive, n_posix_char *path, n_posix_char *lval )
{

	if ( n_nekonote_new_is_system )
	{
		(*hive) = HKEY_LOCAL_MACHINE;
	} else {
		(*hive) = HKEY_CURRENT_USER;
	}

	n_posix_sprintf_literal( path, "Software\\Classes\\%s\\ShellNew", n_nekonote_new_ext );

	n_posix_sprintf_literal( lval, "%s", n_posix_literal( "FileName" ) );


	return;
}

void
n_nekonote_new_filename_template_add( void )
{

	HKEY         hive;
	n_posix_char path[ N_PATH_MAX ];
	n_posix_char lval[ N_PATH_MAX ];

	n_nekonote_new_filename_init( &hive, path, lval );


	n_posix_char template[ N_PATH_MAX ];
	n_win_txtbox_selection_get( &n_nekonote_new_input_ext, template );

	size_t  cb = n_posix_strlen( template ) * sizeof( n_posix_char );
	DWORD  ret = n_registry_write( hive, path, lval, REG_SZ, template, cb );

	if ( ret ) { n_nekonote_new_error(); }


	return;
}

void
n_nekonote_new_name_init( HKEY *hive, n_posix_char *path, n_posix_char *lval )
{

	if ( n_nekonote_new_is_system )
	{
		(*hive) = HKEY_LOCAL_MACHINE;
	} else {
		(*hive) = HKEY_CURRENT_USER;
	}

	n_posix_sprintf_literal( path, "Software\\Classes\\%s", n_nekonote_new_typ );

	n_posix_sprintf_literal( lval, "%s", n_posix_literal( "" ) );


	return;
}

void
n_nekonote_new_name_add( void )
{

	HKEY         hive;
	n_posix_char path[ N_PATH_MAX ];
	n_posix_char lval[ N_PATH_MAX ];

	n_nekonote_new_name_init( &hive, path, lval );


	n_posix_char name[ N_PATH_MAX ];
	n_win_txtbox_selection_get( &n_nekonote_new_input_typ, name );

	int   name_cb = n_posix_strlen( name ) * sizeof( n_posix_char );
	DWORD ret     = n_registry_write( hive, path, lval, REG_SZ, name, name_cb );

	if ( ret ) { n_nekonote_new_error(); }


	return;
}

void
n_nekonote_new_init( void )
{

	HKEY         hive;
	n_posix_char path[ N_PATH_MAX ];
	n_posix_char lval[ N_PATH_MAX ];


	// [!] : small buttons

	n_win_txtbox_smallbutton_embed( &n_nekonote_new_input_ext, &n_nekonote_new_smallbutton_ext, 0, true );
	n_win_txtbox_smallbutton_embed( &n_nekonote_new_input_typ, &n_nekonote_new_smallbutton_typ, 0, true );


	// [!] : Extension

	n_win_hwndprintf_literal( H_EXT_LINE, "Extension : %s", n_nekonote_new_ext );


	n_nekonote_new_nullfile_init( &hive, path, lval );

	if ( n_registry_is_exist( hive, path, lval ) )
	{
		n_win_hwndprintf_literal( H_EXT_LABEL,  "Register : (Registered)" );
		n_win_hwndprintf_literal( H_EXT_BUTTON, "Unregister" );
	} else {
		n_win_hwndprintf_literal( H_EXT_LABEL,  "Register : (Not registered)" );
		n_win_hwndprintf_literal( H_EXT_BUTTON, "Register" );
	}


	if ( n_registry_is_exist( hive, path, lval ) )
	{
		n_win_check_onoff( &n_nekonote_new_check_ext, true );
		EnableWindow( H_EXT_TEMPLATE,                true );
		EnableWindow( n_nekonote_new_check_ext.hwnd, true );
		n_win_txtbox_grayed( &n_nekonote_new_input_ext, true );

		ShowWindow( n_nekonote_new_smallbutton_ext.hgui, SW_NORMAL );

		n_posix_sprintf_literal( lval, "%s", n_posix_literal( "FileName" ) );
		if ( n_registry_is_exist( hive, path, lval ) )
		{
			n_posix_char template[ N_PATH_MAX ] = N_STRING_EMPTY;
			n_registry_read( hive, path, lval, template, N_PATH_MAX * sizeof( n_posix_char ) );
			n_win_txtbox_line_set( &n_nekonote_new_input_ext, 0, template );
		}
	} else {
		n_win_check_onoff( &n_nekonote_new_check_ext, false );
		EnableWindow( H_EXT_TEMPLATE,                false );
		EnableWindow( n_nekonote_new_check_ext.hwnd, false );
		n_win_txtbox_grayed( &n_nekonote_new_input_ext, false );

		ShowWindow( n_nekonote_new_smallbutton_ext.hgui, SW_HIDE );
	}


	// [!] : File Type

	n_win_hwndprintf_literal( H_TYP_LINE, "File Type : %s", n_nekonote_new_typ );


	// [!] : an empty path name will be opened as most top-level default key

	n_posix_sprintf_literal( path, "%s", n_nekonote_new_typ );

	bool typ_onoff = true;

	if ( n_string_is_empty( path ) )
	{
		typ_onoff = false;
	}

	n_nekonote_new_name_init( &hive, path, lval );

	if (
		( typ_onoff )
		//&&
		//( n_registry_is_exist( hive, path, lval ) )
	)
	{
		n_posix_char newfile[ N_PATH_MAX ] = N_STRING_EMPTY;
		n_string_truncate( lval );
		n_registry_read( hive, path, lval, newfile, N_PATH_MAX * sizeof( n_posix_char ) );
		n_win_txtbox_line_set( &n_nekonote_new_input_typ, 0, newfile );

		n_win_check_onoff( &n_nekonote_new_check_typ, true );
		EnableWindow( H_TYP_NAME,  true );
		EnableWindow( n_nekonote_new_check_typ.hwnd, true );
		n_win_txtbox_grayed( &n_nekonote_new_input_typ, true );

		ShowWindow( n_nekonote_new_smallbutton_typ.hgui, SW_NORMAL );
	} else {
		n_win_check_onoff( &n_nekonote_new_check_typ, false );
		EnableWindow( H_TYP_NAME                   , false );
		EnableWindow( n_nekonote_new_check_typ.hwnd, false );
		n_win_txtbox_grayed( &n_nekonote_new_input_typ, false );

		ShowWindow( n_nekonote_new_smallbutton_typ.hgui, SW_HIDE );
	}


	return;
}

void
n_nekonote_new_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hpopup )
{

	switch( msg ) {


	case WM_DROPFILES :
	{

		if ( false == IsWindow( hpopup ) ) { break; }


		n_posix_char cmdline[ N_PATH_MAX ];

		n_win_dropfiles( hwnd, wparam, cmdline );

		if ( n_win_check_is_checked( &n_nekonote_new_check_ext ) )
		{
			n_win_txtbox_line_set( &n_nekonote_new_input_ext, 0, cmdline );
		}

		if ( n_win_check_is_checked( &n_nekonote_new_check_typ ) )
		{
			n_posix_char productname[ N_PATH_MAX ];
			n_sysinfo_fileversion_literal( cmdline, "ProductName", productname, N_PATH_MAX );
			if ( n_string_is_empty( productname ) )
			{
				n_path_name( cmdline, productname );
				n_path_ext_del( productname );
			}
			n_win_txtbox_line_set( &n_nekonote_new_input_typ, 0, productname );
		}


		SetActiveWindow( hpopup );

	}
	break;


	} // switch


	return;
}

void
n_nekonote_new_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, 500 );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );

		n_win_radio_on_settingchange( &n_nekonote_new_radio_hklm );
		n_win_radio_on_settingchange( &n_nekonote_new_radio_hkcu );

		n_win_check_on_settingchange( &n_nekonote_new_check_ext );
		n_win_check_on_settingchange( &n_nekonote_new_check_typ );

		n_win_smallbutton_on_settingchange_by_data( &n_nekonote_new_smallbutton_ext, H_EXT_SMLBTN, n_project_small_save );
		n_win_smallbutton_on_settingchange_by_data( &n_nekonote_new_smallbutton_typ, H_TYP_SMLBTN, n_project_small_save );

		n_win_stdfont_init( n_nekonote_new_hgui, GUI_MAX );

	break;


	} // switch


}

LRESULT CALLBACK
n_nekonote_new_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_nekonote_new_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global


		// Window

		n_win_init_literal( hwnd, "New File Tweaker", "", "" );

		n_win_radio_zero( &n_nekonote_new_radio_hklm );
		n_win_radio_zero( &n_nekonote_new_radio_hkcu );
		n_win_radio_init( &n_nekonote_new_radio_hklm, hwnd, N_NEKONOTE_NEW_HKLM, 0 );
		n_win_radio_init( &n_nekonote_new_radio_hkcu, hwnd, N_NEKONOTE_NEW_HKCU, 0 );

		n_win_check_zero( &n_nekonote_new_check_ext );
		n_win_check_zero( &n_nekonote_new_check_typ );
		n_win_check_init( &n_nekonote_new_check_ext, hwnd, N_STRING_EMPTY, 0 );
		n_win_check_init( &n_nekonote_new_check_typ, hwnd, N_STRING_EMPTY, 0 );

		{
			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_ONELINE;

			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET;

			n_win_txtbox_zero( &n_nekonote_new_input_ext );
			n_win_txtbox_zero( &n_nekonote_new_input_typ );

			n_win_txtbox_init( &n_nekonote_new_input_ext, hwnd, style, option );
			n_win_txtbox_init( &n_nekonote_new_input_typ, hwnd, style, option );
		}

		n_win_gui_literal( hwnd, CANVAS, "", &H_EXT_LINE     );
		n_win_gui_literal( hwnd, LABEL,  "", &H_EXT_LABEL    );
		n_win_gui_literal( hwnd, FBTN,   "", &H_EXT_BUTTON   );
		n_win_gui_literal( hwnd, LABEL,  "", &H_EXT_TEMPLATE );
		n_win_gui_literal( hwnd, CANVAS, "", &H_EXT_SMLBTN   );

		n_win_gui_literal( hwnd, CANVAS, "", &H_TYP_LINE     );
		n_win_gui_literal( hwnd, LABEL,  "", &H_TYP_NAME     );
		n_win_gui_literal( hwnd, CANVAS, "", &H_TYP_SMLBTN   );

		n_win_gui_literal( hwnd, CANVAS, "", &H_PAD_LINE     );


		n_win_hwndprintf( H_EXT_TEMPLATE, N_NEKONOTE_NEW_TEMPLATE );
		n_win_hwndprintf( H_TYP_NAME,     N_NEKONOTE_NEW_NAME     );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW    );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );

		n_win_style_add( n_nekonote_new_radio_hklm.hwnd, BS_CENTER );
		n_win_style_add( n_nekonote_new_radio_hkcu.hwnd, BS_CENTER );

		n_win_style_add( n_nekonote_new_check_ext.hwnd, BS_CENTER );
		n_win_style_add( n_nekonote_new_check_typ.hwnd, BS_CENTER );

		n_win_iconbutton_init( hwnd, H_EXT_BUTTON );

		n_win_smallbutton_init_by_data( &n_nekonote_new_smallbutton_ext, H_EXT_SMLBTN, n_project_small_save );
		n_win_smallbutton_init_by_data( &n_nekonote_new_smallbutton_typ, H_TYP_SMLBTN, n_project_small_save );


		// Size

		n_win_stdfont_init( n_nekonote_new_hgui, GUI_MAX );


		{ // n_nekonote_new_resize()

		const bool redraw = false;


		s32 ctl,m; n_win_stdsize( hwnd, &ctl, NULL, &m );

		s32 csx,csy; n_win_desktop_size( &csx, NULL );
		csx = n_posix_max_s32( 333, (double) csx * 0.25 );
		csy = ctl * 6;
		if ( n_sysinfo_version_xp_or_later() ) { csy = ctl * 7; }


		s32 patch_csx = csx + m;
		s32 patch_csy = csy + m;

		n_win_set_patch( hwnd, &patch_csx, &patch_csy, 7, 7 );

		n_win_set( hwnd, NULL, patch_csx, patch_csy, N_WIN_SET_CENTERING );


		s32 u   = ( csx / 10 );
		s32 osx = ( csx % 10 ) + u;
		s32 isx = csx - osx;
		s32 x   = 0;
		s32 y   = 0;
		s32 chk = ( u - ctl ) / 2;

		s32 label = 0;
		n_win_stdsize_text( H_TYP_NAME, N_NEKONOTE_NEW_NAME, &label, NULL );
		    label = label + m * 2;
		s32 input = isx - label;


		// [!] : Radio Buttons

		{

			int hlf = csx / 2;

			n_win_move( n_nekonote_new_radio_hklm.hwnd, x,y, hlf,ctl, redraw ); x += hlf; 
			n_win_move( n_nekonote_new_radio_hkcu.hwnd, x,y, hlf,ctl, redraw );

		}

		y += ctl;


		// [!] : Extension

		x = 0;

		n_win_move( H_EXT_LINE, x,y, csx,ctl, redraw ); y += ctl;


		{

			s32 lb1 = isx / 4 * 3;
			s32 bt1 = isx / 4 * 1;

			x = osx;
			n_win_move( H_EXT_LABEL,  x,y, lb1,ctl, redraw );
			x = osx + lb1;
			n_win_move( H_EXT_BUTTON, x,y, bt1,ctl, redraw );

		}


		if ( n_sysinfo_version_xp_or_later() )
		{

			y += ctl;

			x = chk;
			n_win_move( n_nekonote_new_check_ext.hwnd, x,y, ctl,ctl, redraw );

			x = osx;

			n_win_move( H_EXT_TEMPLATE               , x,y, label,ctl, redraw ); x += label;
			n_win_move( n_nekonote_new_input_ext.hwnd, x,y, input,ctl, redraw );

		}


		// [!] : File Type

		x  = 0;
		y += ctl;

		n_win_move( H_TYP_LINE, x,y, csx,ctl, redraw ); y += ctl;

		{

			x = chk;
			n_win_move( n_nekonote_new_check_typ.hwnd, x,y, ctl,ctl, redraw );

			x = osx;

			n_win_move( H_TYP_NAME                   , x,y, label,ctl, redraw ); x += label;
			n_win_move( n_nekonote_new_input_typ.hwnd, x,y, input,ctl, redraw );

		}

		// [!] Padding

		x  = 0;
		y += ctl;

		n_win_move( H_PAD_LINE, x,y, csx,ctl, redraw );


		} // n_nekonote_new_resize()


		// Init

		if ( n_nekonote_new_is_system )
		{
			n_win_radio_check( &n_nekonote_new_radio_hklm );
		} else {
			n_win_radio_check( &n_nekonote_new_radio_hkcu );
		}

		n_nekonote_new_init();


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		EnableWindow( GetParent( hwnd ), false );

	break;


	case WM_NCLBUTTONDOWN :
	case WM_LBUTTONDOWN   :

		SetFocus( hwnd );

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == n_nekonote_new_radio_hklm.hwnd )
		{

			if ( wparam == RBS_CHECKEDHOT )
			{
				n_nekonote_new_is_system =  true;
				n_win_radio_check  ( &n_nekonote_new_radio_hklm );
				n_win_radio_uncheck( &n_nekonote_new_radio_hkcu );
			} else {
				n_nekonote_new_is_system = false;
				n_win_radio_check  ( &n_nekonote_new_radio_hkcu );
				n_win_radio_uncheck( &n_nekonote_new_radio_hklm );
			}
//n_win_hwndprintf_literal( hwnd, " %d ", n_nekonote_new_is_system );

			n_nekonote_new_init();

		} else
		if ( (HWND) lparam == n_nekonote_new_radio_hkcu.hwnd )
		{

			if ( wparam == RBS_CHECKEDHOT )
			{
				n_nekonote_new_is_system = false;
				n_win_radio_check  ( &n_nekonote_new_radio_hkcu );
				n_win_radio_uncheck( &n_nekonote_new_radio_hklm );
			} else {
				n_nekonote_new_is_system =  true;
				n_win_radio_check  ( &n_nekonote_new_radio_hklm );
				n_win_radio_uncheck( &n_nekonote_new_radio_hkcu );
			}
//n_win_hwndprintf_literal( hwnd, " %d ", n_nekonote_new_is_system );

			n_nekonote_new_init();

		} else
		if ( (HWND) lparam == n_nekonote_new_input_ext.hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open( hwnd, n_nekonote_new_input_ext.hwnd );
			}

		} else
		if ( (HWND) lparam == n_nekonote_new_input_typ.hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open( hwnd, n_nekonote_new_input_typ.hwnd );
			}

		} else
		if ( (HWND) lparam == H_EXT_BUTTON )
		{
			n_nekonote_new_nullfile_addremove();
			n_nekonote_new_init();
		} else
		if ( (HWND) lparam == H_EXT_SMLBTN )
		{
			n_nekonote_new_filename_template_add();
			n_nekonote_new_init();
		} else
		if ( (HWND) lparam == H_TYP_SMLBTN )
		{
			n_nekonote_new_name_add();
			n_nekonote_new_init();
		}

	break;


	case WM_CLOSE :
	{

		n_win_inputpopup_autoclose();


		n_win_radio_exit( &n_nekonote_new_radio_hklm );
		n_win_radio_exit( &n_nekonote_new_radio_hkcu );


		n_win_check_exit( &n_nekonote_new_check_ext );
		n_win_check_exit( &n_nekonote_new_check_typ );


		n_win_txtbox_exit( &n_nekonote_new_input_ext );
		n_win_txtbox_exit( &n_nekonote_new_input_typ );


		n_win_smallbutton_exit( &n_nekonote_new_smallbutton_ext );
		n_win_smallbutton_exit( &n_nekonote_new_smallbutton_typ );


		n_win_stdfont_exit( n_nekonote_new_hgui, GUI_MAX );


		EnableWindow( GetParent( hwnd ), true );


		DestroyWindow( hwnd );

	}
	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret != 0 ) { return ret; }
	}


	n_win_radio_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_radio_hklm );
	n_win_radio_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_radio_hkcu );


	n_win_check_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_check_ext );
	n_win_check_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_check_typ );


	{
		int ret = 0;

		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_input_ext );
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_input_typ );

		if ( ret ) { return ret; }
	}


	n_win_inputpopup_proc_light( hwnd, msg, wparam, lparam, n_nekonote_new_input_ext.hwnd );
	n_win_inputpopup_proc_light( hwnd, msg, wparam, lparam, n_nekonote_new_input_typ.hwnd );
	n_win_inputpopup_patch( hwnd, msg, &wparam, &lparam );


	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_EXT_BUTTON );


	n_win_separator_proc( hwnd, msg, wparam, lparam, H_EXT_LINE, PS_SOLID );
	n_win_separator_proc( hwnd, msg, wparam, lparam, H_TYP_LINE, PS_SOLID );
	n_win_separator_proc( hwnd, msg, wparam, lparam, H_PAD_LINE, PS_SOLID );


	n_win_smallbutton_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_smallbutton_ext );
	n_win_smallbutton_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_smallbutton_typ );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}
/*
int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_nekonote_new_wndproc );
}
*/


#undef H_EXT_LINE
#undef H_EXT_LABEL
#undef H_EXT_BUTTON
#undef H_EXT_TEMPLATE
#undef H_EXT_SMLBTN
#undef H_TYP_LINE
#undef H_TYP_NAME
#undef H_TYP_SMLBTN
#undef H_PAD_LINE
#undef GUI_MAX


#undef N_NEKONOTE_NEW_HKLM
#undef N_NEKONOTE_NEW_HKCU
#undef N_NEKONOTE_NEW_TEMPLATE
#undef N_NEKONOTE_NEW_NAME


