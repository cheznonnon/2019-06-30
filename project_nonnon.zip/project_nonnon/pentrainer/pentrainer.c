// Nonnon Pen Trainer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"




#include "../nonnon/com/IShellLink.c"


#include "../nonnon/neutral/bmp/all.c"


#include "../nonnon/win32/win.c"

#include "../nonnon/win32/gdi.c"
#include "../nonnon/win32/gdi/bitmap.c"
#include "../nonnon/win32/gdi/dibsection.c"

#include "../nonnon/win32/explorer.c"

#include "../nonnon/win32/ole/IDropTarget.c"

#include "../nonnon/win32/wintab.c"

#include "../nonnon/game/direct2d.c"


#include "../nonnon/project/macro.c"




// Components

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_PENTRAINER ( 0 )

#endif // #ifndef NONNON_APPS


#include "_extern.c"

#include "pentrainer_refresh.c"

#include "pentrainer_pen.c"

#include "pentrainer_config.c"
#include "pentrainer_ini.c"
#include "pentrainer_ui.c"




void
n_pentrainer_character( n_bmp *bmp, s32 size, n_posix_char *str )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = size;
	gdi.sy                  = size;
	gdi.scale               = N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_SMOOTH;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = n_bmp_white_invisible;
	gdi.base_color_fg       = n_bmp_white_invisible;
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = N_GDI_FRAME_NOFRAME;
	gdi.frame_round         = 0;

	gdi.text                = str;
	gdi.text_font           = n_pentrainer_font;
	gdi.text_size           = size;
	gdi.text_style          = N_GDI_TEXT_CONTOUR;
	gdi.text_color_main     = n_bmp_white_invisible;
	gdi.text_color_gradient = n_pentrainer_color_fg;
	gdi.text_color_shadow   = n_pentrainer_color_fg;
	gdi.text_color_contour  = n_pentrainer_color_fg;
	gdi.text_color_sink_tl  = n_pentrainer_color_fg;
	gdi.text_color_sink_br  = n_pentrainer_color_fg;
	gdi.text_fxsize1        = 0;
	gdi.text_fxsize2        = 4;


	n_gdi_bmp( &gdi, bmp );


	return;
}

// internal
void
n_pentrainer_canvaspos( s32 *ret_x, s32 *ret_y )
{

	s32 x,y;

#ifdef _H_NONNON_WIN32_WIN_WINTAB

	if ( ( n_pentrainer_wintab_onoff )&&( n_wintab_is_pressed( &n_pentrainer_wintab ) ) )
	{
//n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "WinTab : On" );

		POINT pt = { n_wintab_cursor_x( &n_pentrainer_wintab ), GetSystemMetrics( SM_CYSCREEN ) - n_wintab_cursor_y( &n_pentrainer_wintab ) };

		ScreenToClient( n_pentrainer_hwnd_main, &pt );

		x = pt.x;
		y = pt.y;

	} else

#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB

	{
//n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "WinTab : Off" );

		n_win_cursor_position_relative( n_pentrainer_hwnd_main, &x, &y );

	}

	s32 msx,msy; n_pentrainer_margin_get( &msx, &msy );
	x -= msx;
	y -= msy;

	x += nwin_main.scrollx;
	y += nwin_main.scrolly;

	n_pentrainer_zoom_canvas2bitmap( &x, &y, NULL, NULL );


	if ( ret_x ) { *ret_x = x; }
	if ( ret_y ) { *ret_y = y; }


	return;
}

void
n_pentrainer_bitmap( void )
{

	n_bmp_flush           ( &n_pentrainer_bmp_data, n_pentrainer_color_bg                );
	n_pentrainer_character( &n_pentrainer_bmp_over, n_pentrainer_size, n_pentrainer_char );

	n_pentrainer_refresh_client();


	return;
}

void
n_pentrainer_first( HWND hwnd )
{

	// [Needed]
	//
	//	don't rely on n_win_gui()/CreateWindow()'s return value

	n_pentrainer_hwnd_main = hwnd;


	s32 desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );

	n_pentrainer_size = (double) n_posix_min_s32( desktop_sx, desktop_sy ) * 0.25;
	n_pentrainer_size = n_pentrainer_size / N_PENTRAINER_GRID_UNIT * N_PENTRAINER_GRID_UNIT;

	n_bmp_new_fast( &n_pentrainer_bmp_data, n_pentrainer_size, n_pentrainer_size );
	n_bmp_new_fast( &n_pentrainer_bmp_over, n_pentrainer_size, n_pentrainer_size );


	n_pentrainer_pensize     = (double) n_pentrainer_size * 0.05;
	n_pentrainer_zoom        = N_PENTRAINER_ZOOM_ZERO + 1;
	n_pentrainer_mix         = 10;
	n_pentrainer_edge        = 25;
	n_pentrainer_grid_onoff  = true;
	n_pentrainer_frame_onoff = false;


	n_win_stdsize( hwnd, NULL, &n_pentrainer_std_icon_size, NULL );


	//n_pentrainer_color_bg  = n_bmp_white;
	//n_pentrainer_color_fg  = n_bmp_black;
	//n_pentrainer_color_pen = n_bmp_rgb( 0,200,255 );

	n_pentrainer_color_bg  = n_win_darkmode_systemcolor_rgb2pal( COLOR_WINDOW     );
	n_pentrainer_color_fg  = n_win_darkmode_systemcolor_rgb2pal( COLOR_WINDOWTEXT );
	n_pentrainer_color_pen = n_win_darkmode_systemcolor_rgb2pal( COLOR_HIGHLIGHT  );

	if ( false == n_win_color_is_highcontrast() )
	{
		n_pentrainer_color_pen = n_win_dwm_windowcolor();
	}


	n_pentrainer_character_min( n_pentrainer_mode, n_pentrainer_char );
	n_pentrainer_character_move( 0 );


	//n_pentrainer_bitmap();
	n_bmp_flush           ( &n_pentrainer_bmp_data, n_pentrainer_color_bg                );
	n_pentrainer_character( &n_pentrainer_bmp_over, n_pentrainer_size, n_pentrainer_char );


	n_pentrainer_refresh_all();


	return;
}

LRESULT CALLBACK
n_pentrainer_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_SETTINGCHANGE :

		n_pentrainer_first( hwnd );

	break;

	case WM_DISPLAYCHANGE :

		n_pentrainer_first( hwnd );

	break;


	case WM_CREATE :


		// Initialization

		n_bmp_safemode = false;

		n_bmp_zero( &n_pentrainer_bmp_data );
		n_bmp_zero( &n_pentrainer_bmp_over );
		n_gdi_dibsection_zero( &n_pentrainer_dibsection, &n_pentrainer_bmp_dbuf );


		// Global

		n_game_timegettime_init();

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_win_ime_disable( hwnd );
		n_win_tabletpc_disable( hwnd );


		n_project_darkmode();
		//n_win_darkmode_onoff = true;


		n_win_exedir2curdir();
		n_pentrainer_ini_read();

		n_pentrainer_first( hwnd );


#ifdef _H_NONNON_WIN32_WIN_WINTAB

		n_wintab_zero( &n_pentrainer_wintab );
		if ( n_pentrainer_wintab_onoff ) { n_wintab_init( &n_pentrainer_wintab, hwnd ); }

#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


		// Window

		n_win_init_literal( hwnd, N_PENTRAINER_APPNAME, "PENTRAINER_A_ICON", "PENTRAINER_B_PEN" );

		n_win_style_new( hwnd, N_WS_FIXEDWINDOW );


		n_pentrainer_ui_init( hwnd );


		// Display

//n_posix_debug_literal( "%d", 1 );
		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :

		// [!] : for Shortcut(.LNK) with "Maximized Window"

		if ( IsZoomed( hwnd ) ) { ShowWindow( hwnd, SW_NORMAL ); }

	break;


	case WM_ERASEBKGND :

		return true;

	break;

	case WM_PAINT :
	{

		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		s32 msx,msy; n_pentrainer_margin_get( &msx,&msy );
		n_win_rect_move( &ps.rcPaint, -msx, -msy );
		n_win_rect_move( &ps.rcPaint, nwin_main.scrollx, nwin_main.scrolly );

		s32 fx,fy,tx,ty;
		n_win_rect_expand_range( &ps.rcPaint, &fx, &fy, &tx, &ty );

//n_win_hwndprintf_literal( hwnd, "%d %d %d", ps.fErase, ps.fRestore, ps.fIncUpdate );
//n_win_hwndprintf_literal( hwnd, "%d %d %d %d", fx,fy,tx,ty );

		n_pentrainer_zoom_canvas2bitmap( &fx, &fy, &tx, &ty );

		n_pentrainer_refresh( fx,fy,tx,ty, N_PENTRAINER_REFRESH_CLIENT );


		EndPaint( hwnd, &ps );

	}
	break;


	case WM_CLOSE :

		n_bmp_free( &n_pentrainer_bmp_data );
		n_bmp_free( &n_pentrainer_bmp_over );
		n_gdi_dibsection_exit( &n_pentrainer_dibsection, &n_pentrainer_bmp_dbuf );


		n_pentrainer_ini_write();


#ifdef _H_NONNON_WIN32_WIN_WINTAB
		n_wintab_exit( &n_pentrainer_wintab );
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET


		n_game_timegettime_exit();


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


#ifdef _H_NONNON_WIN32_WIN_WINTAB
	if ( n_pentrainer_wintab_onoff ) { n_wintab_packet_proc( hwnd, msg, wparam, lparam, &n_pentrainer_wintab ); }
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


	n_pentrainer_pen_proc( hwnd, msg, wparam, lparam );


	n_pentrainer_ui_proc( hwnd, msg, wparam, lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int
n_pentrainer_main( void )
{

#ifdef _H_NONNON_WIN32_GAME_DIRECT2D

	if ( n_project_dwm_is_on() )
	{
		n_direct2d_init();
		//if ( n_direct2d_is_on() ) { n_win_dwm_transparent_on( hwnd ); }
	}

#endif // #ifdef _H_NONNON_WIN32_GAME_DIRECT2D


	WPARAM ret = n_win_main( NULL, n_pentrainer_wndproc );


#ifdef _H_NONNON_WIN32_GAME_DIRECT2D

	// [x] : don't put this in WndProc()

	if ( n_project_dwm_is_on() )
	{
		n_direct2d_exit();
	}
	
#endif // #ifdef _H_NONNON_WIN32_GAME_DIRECT2D


	return ret;
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_pentrainer_main();
}

#endif // #ifndef NONNON_APPS

