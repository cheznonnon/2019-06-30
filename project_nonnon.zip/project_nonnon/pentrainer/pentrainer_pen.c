// Nonnon Pen Trainer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static int    n_pentrainer_pen_radius = 0;
static double n_pentrainer_pen_blend  = 0;
static bool   n_pentrainer_pen_start  = false;




// internal
double
n_pentrainer_pen_edge( s32 x, s32 y, s32 r, double coeff )
{

	if ( n_pentrainer_edge == 0 ) { return coeff; }


	const double xx = x * x;
	const double yy = y * y;
	const double rr = r * r;

	const double dx = xx / rr;
	const double dy = yy / rr;

	const double dd = 1.0 - ( dx + dy );
	const double ed = 1.0 - ( n_pentrainer_edge / 100.0 );


	return coeff * n_posix_min_double( 1.0, dd + ed - 0.5 );
}

// internal
void
n_pentrainer_pen_engine( s32 fx, s32 fy, double blend )
{

	if ( blend == 0.0 ) { return; }


	int radius = n_pentrainer_pen_radius;


	// [Patch] : size will be smaller when smooth is ON

	if ( blend < 1.0 ) { radius++; }

//n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "%d %x %f", radius, color, blend );

	s32 x = -radius;
	s32 y = -radius;
	while( 1 )
	{

		double coeff;
		if (
			( radius == 0 )
			||
			( n_bmp_ellipse_detect_coeff( x,y, radius,radius, &coeff ) )
		)
		{

			s32 tx = fx + x;
			s32 ty = fy + y;

			u32 color = 0;
			n_bmp_ptr_get( &n_pentrainer_bmp_data, tx,ty, &color );

			color = n_bmp_blend_pixel( color, n_pentrainer_color_pen, blend * coeff );

			n_bmp_ptr_set( &n_pentrainer_bmp_data, tx,ty,  color );

		}


		x++;
		if ( x > radius )
		{

			x = -radius;

			y++;
			if ( y > radius ) { break; }
		}

	}


	return;
}

// internal
void
n_pentrainer_pen_refresh( s32 fx, s32 fy, s32 tx, s32 ty )
{

//n_pentrainer_refresh_all(); return;


	// [Needed] : +1

	s32 redraw_fx = n_posix_min_s32( fx, tx ) - n_pentrainer_pen_radius;
	s32 redraw_fy = n_posix_min_s32( fy, ty ) - n_pentrainer_pen_radius;
	s32 redraw_tx = n_posix_max_s32( fx, tx ) + n_pentrainer_pen_radius + 1;
	s32 redraw_ty = n_posix_max_s32( fy, ty ) + n_pentrainer_pen_radius + 1;

	n_pentrainer_refresh
	(
		redraw_fx, redraw_fy,
		redraw_tx, redraw_ty,
		N_PENTRAINER_REFRESH_CLIENT
	);


	return;
}

#define N_PENTRAINER_PEN_START 0
#define N_PENTRAINER_PEN_LOOP  1
#define N_PENTRAINER_PEN_STOP  2

#define n_pentrainer_pen_start() n_pentrainer_pen( N_PENTRAINER_PEN_START )
#define n_pentrainer_pen_loop()  n_pentrainer_pen( N_PENTRAINER_PEN_LOOP  )
#define n_pentrainer_pen_stop()  n_pentrainer_pen( N_PENTRAINER_PEN_STOP  )

void
n_pentrainer_pen( int mode )
{

	static s32 start_x;
	static s32 start_y;

	static s32 px;
	static s32 py;


	s32 fx,fy, tx,ty;

	n_pentrainer_canvaspos( &tx, &ty );

	if ( mode == N_PENTRAINER_PEN_START )
	{

		start_x = px = fx = tx;
		start_y = py = fy = ty;

	} else {

		if ( mode == N_PENTRAINER_PEN_STOP )
		{
			if ( ( start_x == tx )&&( start_y == ty ) ) { return; }
		}

		fx = px;
		fy = py;

	}


	if (
		( mode == N_PENTRAINER_PEN_LOOP )
		&&
		( n_pentrainer_pen_blend != 1.0 )
	)
	{

		// [Needed] : n_pentrainer_pen_line_wu() : for color stability

		{

			const int threshold = 2;

			if (
				( threshold > abs( fx - tx ) )
				&&
				( threshold > abs( fy - ty ) )
			)
			{
				return;
			}

		}


		// [!] : nothing to do

		if ( ( fx == tx )&&( fy == ty ) ) { return; }

	}


#ifdef _H_NONNON_WIN32_WIN_WINTAB

//n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "%d / %d", n_wintab_pressure_get( &n_pentrainer_wintab ), n_wintab_pressure_max( &n_pentrainer_wintab ) );
	if ( ( n_pentrainer_wintab_onoff )&&( n_wintab_is_pressed( &n_pentrainer_wintab ) ) )
	{
		double max = n_wintab_pressure_max( &n_pentrainer_wintab );
		double cur = n_wintab_pressure_get( &n_pentrainer_wintab );

		double pen = (double) n_pentrainer_pensize * ( cur / max );
		n_pentrainer_pen_radius = pen / 2;

		n_pentrainer_pen_blend = (double) ( n_pentrainer_mix * 0.01 ) * ( cur / max );
	}
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


	if ( n_pentrainer_pen_blend == 1.0 )
	{
		n_bmp_pen_bresenham( fx,fy, tx,ty, n_pentrainer_pen_blend, n_pentrainer_pen_engine );
	} else {
		n_bmp_pen_wu       ( fx,fy, tx,ty, n_pentrainer_pen_blend, n_pentrainer_pen_engine );
	}

	px = tx;
	py = ty;


	n_pentrainer_pen_refresh( fx,fy, tx,ty );


	return;
}

void
n_pentrainer_pen_on_lbuttondown( HWND hwnd )
{

	{

		if ( false == n_pentrainer_is_inner_canvas() )
		{
			return;
		}


		if ( n_pentrainer_pen_start == false )
		{

			n_pentrainer_pen_start = true;


			n_win_cursor_add_literal( NULL, "PENTRAINER_B_PEN_ON" );

			SetCapture( hwnd );


			// [!] : pre-calculate

			n_pentrainer_pen_radius = n_pentrainer_pensize / 2;
			n_pentrainer_pen_blend  = (double) n_pentrainer_mix * 0.01;


			// [!] : the first input

			n_pentrainer_pen_start();

		}

	}


	return;
}

void
n_pentrainer_pen_on_mousemove( HWND hwnd )
{

	{

		if ( n_pentrainer_pen_start )
		{

			if ( false == n_win_is_input( VK_CONTROL ) )
			{
				n_pentrainer_pen_loop();
			}

		} else {

			if ( n_pentrainer_is_inner_canvas() )
			{
				n_win_cursor_add_literal( hwnd, "PENTRAINER_B_PEN" );
			} else {
				n_win_cursor_add( hwnd, IDC_ARROW );
			}

		}

	}


	return;
}

void
n_pentrainer_pen_on_lbuttonup( HWND hwnd )
{

	{

		if ( n_pentrainer_pen_start )
		{

			n_pentrainer_pen_stop();


			ReleaseCapture();
			n_win_cursor_add_literal( NULL, "PENTRAINER_B_PEN" );


			n_pentrainer_pen_start = false;

		}

	}


	return;
}

void
n_pentrainer_pen_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_LBUTTONDOWN :

		n_pentrainer_pen_on_lbuttondown( hwnd );

	break;

	case WM_MOUSEMOVE :

		n_pentrainer_pen_on_mousemove( hwnd );

	break;

	case WM_LBUTTONUP :

		n_pentrainer_pen_on_lbuttonup( hwnd );

	break;


	} // switch


	return;
}

