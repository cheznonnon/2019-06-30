// NonnonGame
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




#include "../nonnon/game/timegettime.c"
#include "../nonnon/game/game.c"

#include "../nonnon/game/chara.c"
#include "../nonnon/game/input.c"


// [!] : PNG support

#include "../nonnon/neutral/png.c"
#include "../nonnon/game/rc.c"


// [!] : after rc.c

#include "../nonnon/game/sound.c"


// [!] : MIDI trick support

#include "../nonnon/neutral/string_path.c"
#include "../nonnon/win32/resource.c"




// Constants


#define N_NGAME_OBJ_CHARA_0 p->obj[  0 ]
#define N_NGAME_OBJ_BLOCK_0 p->obj[  1 ]
#define N_NGAME_OBJ_PANEL_0 p->obj[  2 ]
#define N_NGAME_OBJ_CHARA_U p->obj[  3 ]
#define N_NGAME_OBJ_BLOCK_U p->obj[  4 ]
#define N_NGAME_OBJ_PANEL_U p->obj[  5 ]
#define N_NGAME_OBJ_CHARA_D p->obj[  6 ]
#define N_NGAME_OBJ_BLOCK_D p->obj[  7 ]
#define N_NGAME_OBJ_PANEL_D p->obj[  8 ]
#define N_NGAME_OBJ_CHARA_L p->obj[  9 ]
#define N_NGAME_OBJ_BLOCK_L p->obj[ 10 ]
#define N_NGAME_OBJ_PANEL_L p->obj[ 11 ]
#define N_NGAME_OBJ_CHARA_R p->obj[ 12 ]
#define N_NGAME_OBJ_BLOCK_R p->obj[ 13 ]
#define N_NGAME_OBJ_PANEL_R p->obj[ 14 ]
#define N_NGAME_OBJ_MAX             15
#define N_NGAME_OBJ_UNIT             3
#define N_NGAME_OBJ_ELEM_0         ( N_NGAME_OBJ_UNIT * 0 )
#define N_NGAME_OBJ_ELEM_U         ( N_NGAME_OBJ_UNIT * 1 )
#define N_NGAME_OBJ_ELEM_D         ( N_NGAME_OBJ_UNIT * 2 )
#define N_NGAME_OBJ_ELEM_L         ( N_NGAME_OBJ_UNIT * 3 )
#define N_NGAME_OBJ_ELEM_R         ( N_NGAME_OBJ_UNIT * 4 )
#define N_NGAME_OBJ_FLAG_U         ( 1 << 1 )
#define N_NGAME_OBJ_FLAG_D         ( 1 << 2 )
#define N_NGAME_OBJ_FLAG_L         ( 1 << 3 )
#define N_NGAME_OBJ_FLAG_R         ( 1 << 4 )


#define N_NGAME_SND_WAV     p->snd[ 0 ]
#define N_NGAME_SND_BGM     p->snd[ 1 ]
#define N_NGAME_SND_MAX             2



typedef struct {

	bool          bgm_init;

	s32           csx,csy;
	s32           zoom;
	s32           unit;
	s32           o;
	s32           step;

	n_bmp         bmp;
	n_game_chara  obj[ N_NGAME_OBJ_MAX ];
	n_game_sound  snd[ N_NGAME_SND_MAX ];

	n_posix_char *midi;

	n_game_input  input;

	bool          aeroglass_onoff;
	bool          smoothloop_onoff;

} n_ngame;


static n_ngame ngame;




#define n_ngame_zero( p ) n_memory_zero( p, sizeof( n_ngame ) )

u32
n_ngame_bgcolor( n_ngame *p )
{

	if ( p->aeroglass_onoff ) { return 0; }


	u32 color = n_bmp_argb2ahsl( n_game_randomcolor() );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = 128;//n_bmp_l( color );

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

void
n_ngame_shuffle_color( n_ngame *p )
{

	game.color = n_ngame_bgcolor( p );


	int i = 0;
	while( 1 )
	{

		p->obj[ i ].bgcolor = game.color;

		i++;
		if ( i >= N_NGAME_OBJ_MAX ) { break; }
	}


	return;
}

bool
n_ngame_is_moved( n_ngame *p )
{

	int i = 0;
	while( 1 )
	{

		if ( n_game_chara_is_moved( &p->obj[ i ] ) ) { return true; }


		i++;
		if ( i >= N_NGAME_OBJ_UNIT ) { break; }
	}


	return false;
}

void
n_ngame_object_collision( n_ngame *p, n_game_chara *f, n_game_chara *t )
{

	if (
		( ( f->x + ( f->sx / 2 ) ) > ( t->x         ) )
		&&
		( ( f->x + ( f->sx / 2 ) ) < ( t->x + t->sx ) )
	)
	{

		// Upper = 1 : Lower = 0

		if (
			( f->y > ( t->y         ) )
			&&
			( f->y < ( t->y + t->sy ) )
		)
		{
			t->y -= p->step;
			f->y  = t->y + t->sy;
		}


		// Upper = 0 : Lower = 1

		if (
			( f->y > ( t->y - t->sy ) )
			&&
			( f->y < ( t->y         ) )
		)
		{
			t->y += p->step;
			f->y  = t->y - t->sy;
		}

	}

	if (
		( ( f->y + ( f->sy / 2 ) ) > ( t->y         ) )
		&&
		( ( f->y + ( f->sy / 2 ) ) < ( t->y + t->sy ) )
	)
	{

		// Left = 0 : Right = 1

		if (
			( f->x > ( t->x - t->sx ) )
			&&
			( f->x < ( t->x         ) )
		)
		{
			t->x += p->step;
			f->x  = t->x - t->sx;
		}


		// Left = 1 : Right = 0

		if (
			( f->x > ( t->x         ) )
			&&
			( f->x < ( t->x + t->sx ) )
		)
		{
			t->x -= p->step;
			f->x  = t->x + t->sx;
		}

	}


	return;
}

void
n_ngame_move( n_ngame *p )
{

	n_game_chara *c = &N_NGAME_OBJ_CHARA_0;

	if ( n_game_input_loop( &p->input, VK_UP    ) ) { c->y -= p->step; }
	if ( n_game_input_loop( &p->input, VK_DOWN  ) ) { c->y += p->step; }
	if ( n_game_input_loop( &p->input, VK_RIGHT ) ) { c->x += p->step; }
	if ( n_game_input_loop( &p->input, VK_LEFT  ) ) { c->x -= p->step; }


	return;
}

bool
n_ngame_is_inner( n_ngame *p, n_game_chara *c )
{

	if (
		( ( c->x >= 0 )&&( ( c->x + c->sx ) < p->csx ) )
		&&
		( ( c->y >= 0 )&&( ( c->y + c->sy ) < p->csy ) )
	)
	{
		return true;
	}


	return false;
}

void
n_ngame_chara_draw( n_ngame *p, n_game_chara *c, bool debug_onoff, u32 debug_color )
{

	if ( debug_onoff )
	{

		n_bmp *bmp_prv = N_NGAME_OBJ_CHARA_0.chara;

		n_bmp bmp;
		n_bmp_zero( &bmp );
		n_bmp_carboncopy( bmp_prv, &bmp );
		n_bmp_flush( &bmp, debug_color );

		c->chara = &bmp;

		n_game_chara_draw( c );

		c->chara = bmp_prv;

		n_bmp_free( &bmp );

	} else {

		n_game_chara_draw( c );

	}


	return;
}

void
n_ngame_bgm( n_ngame *p )
{

	// [x] : not smooth at looping

	if ( false == n_vfw_is_playing( &N_NGAME_SND_BGM.vfw ) )
	{
		n_game_sound_loop( &N_NGAME_SND_BGM );
	}


	return;
}




// [!] : Components

#include "./simple.c"
#include "./smooth.c"

#include "./subclass.c"

void
n_ngame_shuffle( n_ngame *p, int i )
{

	if ( p->smoothloop_onoff )
	{
		n_ngame_smooth_shuffle( p, i );
	} else {
		n_ngame_simple_shuffle( p, i );
	}

	return;
}

void
n_ngame_shuffle_all( n_ngame *p )
{

	if ( p->smoothloop_onoff )
	{
		n_ngame_smooth_shuffle_all( p );
	} else {
		n_ngame_simple_shuffle_all( p );
	}


	return;
}

void
n_ngame_srcx_init( n_ngame *p )
{

	if ( p->smoothloop_onoff )
	{
		n_ngame_smooth_srcx_init( p );
	} else {
		n_ngame_simple_srcx_init( p );
	}


	return;
}

void
n_ngame_collision( n_ngame *p )
{

	if ( p->smoothloop_onoff )
	{
		n_ngame_smooth_collision( p );
	} else {
		n_ngame_simple_collision( p );
	}


	return;
}

void
n_ngame_edgelooping( n_ngame *p )
{

	if ( p->smoothloop_onoff )
	{
		n_ngame_smooth_edgelooping( p );
	} else {
		n_ngame_simple_edgelooping( p );
	}


	return;
}

void
n_ngame_draw( n_ngame *p )
{

	if ( p->smoothloop_onoff )
	{
		n_ngame_smooth_draw( p );
	} else {
		n_ngame_simple_draw( p );
	}


	return;
}




void
n_ngame_init( n_ngame *p )
{

	// Global

	n_bmp_safemode = false;


	// Size

	s32 desktop_sx, desktop_sy;
	n_win_desktop_size( &desktop_sx, &desktop_sy );

	p->csx  = p->csy = n_posix_min_s32( desktop_sx, desktop_sy ) / 2;
	p->zoom = n_win_dpi( game.hwnd ) / 96;
	p->unit = 40 * p->zoom;
	p->o    = p->unit / 2;
	p->step = 8;


	// System

	n_game_title_literal( "+++NonnonGame+++" );

	game.sx    = p->csx;
	game.sy    = p->csy;
	game.fps   = 30;
	game.color = n_bmp_white;

	n_game_dwm_onoff();

	if ( game.dwm_onoff )
	{
		if ( n_sysinfo_version_vista() ) { p->aeroglass_onoff = true; }
		if ( n_sysinfo_version_7    () ) { p->aeroglass_onoff = true; }
	}


	n_game_window_resizable();


	n_ngame_subclass_init( p );


	// Resources

	n_game_rc_load_png2bmp_literal( &p->bmp, "NGAME_BMP" );

	n_bmp_scaler_big( &p->bmp, p->zoom );


	n_game_sound_bulk_zero( p->snd, N_NGAME_SND_MAX );

	n_game_sound_init_literal( &N_NGAME_SND_WAV, game.hwnd, "NGAME_WAV" );


	// Reset

	n_game_chara_bulk_zero( p->obj, N_NGAME_OBJ_MAX );
	n_game_chara_bulk_bmp ( p->obj, N_NGAME_OBJ_MAX, &game.bmp, &p->bmp, NULL, 0 );
	n_game_chara_bulk_src ( p->obj, N_NGAME_OBJ_MAX, 0,0, p->unit,p->unit, 0,0 );


	n_game_sound_loop( &N_NGAME_SND_WAV );


	p->smoothloop_onoff =  true;
	//p->smoothloop_onoff = false;


	n_ngame_shuffle_all( p );
	n_ngame_shuffle_color( p );


	n_ngame_srcx_init( p );


	n_game_input_zero( &p->input );
	n_game_input_init( &p->input, 0 );
	n_game_input_vk2udlr_default( &p->input );


	return;
}

void
n_ngame_loop( n_ngame *p )
{

	if ( p->bgm_init == false )
	{

		p->bgm_init = true;

		n_posix_char *name = n_posix_literal( "NGAME_MID" );
		n_posix_char *sect = n_posix_literal( "DATA" );

		p->midi = n_string_path_tmpname_new_literal( ".mid" );

		n_resource_save( name, sect, p->midi );
//n_game_hwndprintf_literal( "%s", p->midi );

		n_game_sound_init( &N_NGAME_SND_BGM, game.hwnd, p->midi );
		n_game_sound_loop( &N_NGAME_SND_BGM );

	}


	// input

	n_ngame_move( p );


	n_game_chara_dnd( &N_NGAME_OBJ_CHARA_0, game.hwnd, VK_LBUTTON );
	n_game_chara_dnd( &N_NGAME_OBJ_BLOCK_0, game.hwnd, VK_LBUTTON );
	n_game_chara_dnd( &N_NGAME_OBJ_PANEL_0, game.hwnd, VK_LBUTTON );




	// collision

	n_ngame_collision( p );


	// looping

	n_ngame_edgelooping( p );


	// draw

	if ( n_game_refresh_is_resize() )
	{

		p->csx = game.sx;
		p->csy = game.sy;

		n_ngame_shuffle_all( p );

	}

	if ( n_ngame_is_moved( p ) )
	{

		n_game_chara *f = &N_NGAME_OBJ_BLOCK_0;
		n_game_chara *t = &N_NGAME_OBJ_PANEL_0;

		if ( n_game_chara_is_hit_offset( f, t, p->o,p->o, 0,0 ) )
		{

			n_game_sound_loop( &N_NGAME_SND_WAV );

			n_ngame_shuffle( p, 2 );
			n_ngame_shuffle_color( p );

			n_game_clear( game.color );

		} else {

			// [!] : erase with previous position

			n_game_chara_bulk_erase( p->obj, N_NGAME_OBJ_MAX );

		}


		n_ngame_draw( p );

	} else {

		n_ngame_bgm( p );

	}


	return;
}

void
n_ngame_exit( n_ngame *p )
{

	n_bmp_free( &p->bmp );

	n_ngame_subclass_exit( p );

	n_game_sound_exit( &N_NGAME_SND_WAV );
	n_game_sound_exit( &N_NGAME_SND_BGM );

	n_game_input_exit( &p->input );

	n_posix_unlink( p->midi );
	n_string_path_free( p->midi );

	n_ngame_zero( p );


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_ngame_zero( &ngame );
	n_ngame_init( &ngame );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_ngame_exit( &ngame );
		n_ngame_init( &ngame );
		n_game_reset();
	}

	n_ngame_loop( &ngame );


	return;
}

void
n_game_exit( void )
{

	n_ngame_exit( &ngame );


	return;
}

#endif // #ifndef N_GAMECONSOLE

