// NonnonGame
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html

// Partial File




#ifndef _WIN64
static WNDPROC n_ngame_subclass_pfunc = NULL;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_ngame_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_ngame_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	n_ngame *p = &ngame;


	switch( msg ) {


	case WM_ACTIVATE :

		if ( wparam == WA_INACTIVE )
		{
			n_vfw_pause ( &N_NGAME_SND_BGM.vfw );
		} else {
			n_vfw_resume( &N_NGAME_SND_BGM.vfw );
			//N_NGAME_SND_BGM.tmr = 0;
			//n_ngame_bgm( p );
		}

	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_ngame_subclass_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_ngame_subclass_init( n_ngame *p )
{

#ifdef _WIN64

	SetWindowSubclass( game.hwnd, n_ngame_subclass, 0, 0 );

#else  // #ifdef _WIN64

	// [!] : once per session

	if ( n_ngame_subclass_pfunc != NULL ) { return; }

	n_ngame_subclass_pfunc = n_win_gui_subclass_set( game.hwnd, n_ngame_subclass );

#endif // #ifdef _WIN64


	return;
}

void
n_ngame_subclass_exit( n_ngame *p )
{

#ifdef _WIN64

	RemoveWindowSubclass( game.hwnd, n_ngame_subclass, 0 );

#else  // #ifdef _WIN64

	if ( n_ngame_subclass_pfunc == NULL ) { return; }

	n_win_gui_subclass_set( game.hwnd, n_ngame_subclass_pfunc );

	n_ngame_subclass_pfunc = NULL;

#endif // #ifdef _WIN64


	return;
}


