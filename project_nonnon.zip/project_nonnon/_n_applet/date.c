// Nonnon Date Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/win.c"

#include "../nonnon/project/macro.c"




DWORD
n_date_set( HWND hwnd )
{

	const n_posix_char *month[] = {

		n_posix_literal("JAN"),
		n_posix_literal("FEB"),
		n_posix_literal("MAR"),
		n_posix_literal("APR"),
		n_posix_literal("MAY"),
		n_posix_literal("JUN"),
		n_posix_literal("JUL"),
		n_posix_literal("AUG"),
		n_posix_literal("SEP"),
		n_posix_literal("OCT"),
		n_posix_literal("NOV"),
		n_posix_literal("DEC")

	};

	const n_posix_char *dayofweek[] = {

		n_posix_literal("Sun"),
		n_posix_literal("Mon"),
		n_posix_literal("Tue"),
		n_posix_literal("Wed"),
		n_posix_literal("Thu"),
		n_posix_literal("Fri"),
		n_posix_literal("Sat")

	};


	SYSTEMTIME systime;
	DWORD      ret;


	GetLocalTime( &systime );


	n_win_hwndprintf_literal
	(
		hwnd,
		"%d %s %s %d",
		systime.wDay,
		dayofweek[ systime.wDayOfWeek     ],
		    month[ systime.wMonth     - 1 ],
		systime.wYear
	);


	ret  = ( 23 - systime.wHour   ) * 60 * 60 * 1000;
	ret += ( 60 - systime.wMinute )      * 60 * 1000;
	ret += ( 60 - systime.wSecond )           * 1000;


	return ret;
}

LRESULT CALLBACK
n_applet_date_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const int timer_id   = 1;
	const u32 timer_msec = 100;


	static HWND hpopup;

	static s64  tilltomorrow = 0;


	switch( msg ) {


	case WM_CREATE :


		n_win_ime_disable( hwnd );


		// [!] : timer for mouse gesture

		SetTimer( hwnd, timer_id, timer_msec, NULL );


		// [!] : disappear : WS_ICONIC + DeleteMenu()

		n_win_init_literal( hwnd, "", "A", "" );

		n_win_style_new( hwnd, N_WS_POPUPWINDOW );
		n_win_sysmenu_disable( hwnd, 1,1,1, 1,1, 1, 0 );


		// Nonnon Applet

		tilltomorrow = n_date_set( hwnd );

		if ( sticky )
		{

			ShowWindow( hwnd, SW_MINIMIZE );

		} else {

			ShowWindow( hwnd, SW_HIDE );

			n_win_message_send( hwnd, WM_QUERYOPEN, 0,0 );

		}

	break;


	case WM_QUERYOPEN :

		// [!] : MoveWindow() will be ignored when in minimized window

		// [x] : how to set restored position
		//
		//	if using WINDOWPLACEMENT
		//
		//	Win9x   : doesn't function
		//	Win2000 : OK, available

		// [x] : cannot get the window animation setting
		//
		//	Win9x   : OK, available
		//	Win2000 : doesn't function
		//
		//	static ANIMATIONINFO ai = { sizeof( ANIMATIONINFO ), 0 };
		//	SystemParametersInfo( SPI_GETANIMATION, 0, &ai, 0 );
		//	ai.iMinAnimate;


		n_win_gui( hwnd, WINDOW, n_applet_popup_wndproc, &hpopup );


		// [!] : return FALSE : all windowing APIs will be ignored

		return FALSE;

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == timer_id )
		{

			n_ie_mousegesture( 8 );

			tilltomorrow -= timer_id * 10;
			if ( 0 > tilltomorrow )
			{
				tilltomorrow = n_date_set( hwnd );
			}

		}

	break;

	case WM_TIMECHANGE :

		tilltomorrow = n_date_set( hwnd );

	break;


	case WM_CLOSE :

		n_win_timer_exit( hwnd, timer_id );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}
/*
int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_applet_date_wndproc );
}
*/
