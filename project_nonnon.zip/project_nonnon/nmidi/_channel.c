// nmidi
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_CHANNEL_MAX ( N_MIDI_CHANNEL_MAX - 1 )




typedef struct {

	// internal

	s32     sound;
	s32     panpot;

	n_bmp  *bmp;
	size_t  count;

	// {!] : temporary use

	s32     note;
	s32     volume;

} n_channel;




#define n_channel_zero( p ) n_memory_zero( p, sizeof( n_channel ) )

void
n_channel_free( n_channel *p )
{

	size_t i = 0;
	while( 1 )
	{

		if ( i >= p->count ) { break; }

		n_bmp_free( &p->bmp[ i ] );

		i++;

	}

	n_memory_free( p->bmp );


	n_channel_zero( p );


	return;
}

void
n_channel_new( n_channel *p, s32 sound, s32 panpot, s32 note_count )
{

	n_channel_free( p );


	p->sound  = sound;
	p->panpot = panpot;
	p->count  = note_count;
	p->bmp    = n_memory_new( p->count * sizeof( n_bmp ) );

	n_memory_zero( p->bmp, p->count * sizeof( n_bmp ) );


	return;
}

void
n_channel_bulk_free( n_channel *p )
{

	s32 i = 0;
	while( 1 )
	{

		n_channel_free( &p[ i ] );

		i++;
		if ( i >= N_CHANNEL_MAX ) { break; }
	}


	return;
}

bool
n_channel_bulk_new( n_channel *p, const n_bmp *data )
{

	s32 i = 0;
	while( 1 )
	{

		n_channel_new( &p[ i ], 0, N_MIDI_PANPOT_CENTER, N_BMP_SX( data ) );

		i++;
		if ( i >= N_CHANNEL_MAX ) { break; }
	}


	return false;
}

bool
n_channel_bulk_load( n_channel *p, const n_bmp *data )
{

	s32 i = 0;
	while( 1 )
	{

		s32 channel, sound, panpot;
		n_midi_bmp_channel_get( data, i, &channel, &sound, &panpot );
//n_posix_debug_literal( "Ch.#%d : %d", i, panpot );

		n_channel_new( &p[ i ], sound, panpot, N_BMP_SX( data ) );

		i++;
		if ( i >= N_CHANNEL_MAX ) { break; }
	}


	return false;
}

void
n_channel_reload( n_channel *p, size_t count )
{

	if ( p->count == count )
	{

		// [!] : nothing to do

	} else
	if ( p->count > count )
	{

		// [!] : shrink

		size_t i = count;
		while( 1 )
		{

			if ( i >= p->count ) { break; }

			n_bmp_free( &p->bmp[ i ] );

			i++;

		}

		p->count = count;
		p->bmp   = n_memory_resize( p->bmp, p->count * sizeof( n_bmp ) );

	} else
	if ( p->count < count )
	{

		// [!] : enlarge

		p->bmp = n_memory_resize( p->bmp, count * sizeof( n_bmp ) );

		size_t i = p->count;
		while( 1 )
		{

			if ( i >= count ) { break; }

			n_bmp_zero( &p->bmp[ i ] );

			i++;

		}

		p->count = count;

	}


	return;
}

bool
n_channel_bulk_reload( n_channel *p, const n_bmp *data )
{

	s32 i = 0;
	while( 1 )
	{

		n_channel_reload( &p[ i ], N_BMP_SX( data ) );

		i++;
		if ( i >= N_CHANNEL_MAX ) { break; }
	}


	return false;
}

