// Tutorial
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"


#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const bool is_resizeable = false;


	static HWND hgui;


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Tutorial", "MAIN_ICON", "" );

		n_win_gui_literal( hwnd, N_WIN_GUI_BUTTON, "Button", &hgui );


		//n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );


		if ( is_resizeable )
		{

			n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

			s32 sx = 512 + ( GetSystemMetrics( SM_CXSIZEFRAME ) * 2 );
			s32 sy = 512 + ( GetSystemMetrics( SM_CYSIZEFRAME ) * 2 ) + GetSystemMetrics( SM_CYCAPTION );

#ifdef _MSC_VER

			s32 scale = n_win_dpi( hwnd ) / 96;

			sx += 8 * scale;
			sy += 8 * scale;

#endif // #ifdef _MSC_VER

			MoveWindow  ( hwnd,       100,100,sx,sy, true );
			//SetWindowPos( hwnd, NULL, 100,100,sx,sy, SWP_NOACTIVATE | SWP_DRAWFRAME );

		} else {

			n_win_style_new( hwnd, N_WS_FIXEDWINDOW );

			s32 sx = 512 + ( GetSystemMetrics( SM_CXFIXEDFRAME ) * 2 );
			s32 sy = 512 + ( GetSystemMetrics( SM_CYFIXEDFRAME ) * 2 ) + GetSystemMetrics( SM_CYCAPTION );

#ifdef _MSC_VER

			s32 scale = n_win_dpi( hwnd ) / 96;

			sx += 10 * scale;
			sy += 10 * scale;

#endif // #ifdef _MSC_VER

			MoveWindow  ( hwnd,       100,100,sx,sy, true );
			//SetWindowPos( hwnd, NULL, 100,100,sx,sy, SWP_NOACTIVATE | SWP_DRAWFRAME );

		}


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		// [Needed] : N_WIN_SET_CALCONLY : for VC++ 2017

		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

		s32 ctl; n_win_stdsize( hwnd, NULL, &ctl, NULL );

		s32 sx = 100;
		s32 sy = ctl;

		n_win_move( hgui, ( w.csx - sx ) / 2, ( w.csy - sy ) / 2, sx,sy, true );


		// [Buggy] : VC++ 2017 : GetWindowRect() reports values passed by SetWindowPos() or MoveWindow()

		{
			RECT r_w; GetWindowRect( hwnd, &r_w );
			RECT r_c; GetClientRect( hwnd, &r_c );

			n_win_hwndprintf_literal( hwnd, " %d %d : %d %d ", r_w.right - r_w.left, r_w.bottom - r_w.top, r_c.right, r_c.bottom );
		}


		// [!] : MinGW and VC++ 2017 : both are the same result
		//
		//	client area  width will be 240
		//	client area height will be 217

		//MoveWindow( hwnd, 100,100,256,256, true );
		//MoveWindow( hgui,   0,  0,256,256, true );

		//SetWindowPos( hwnd, NULL, 100,100,256,256, SWP_NOACTIVATE | SWP_DRAWFRAME );
		//MoveWindow  ( hgui,         0,  0,256,256, true );

	}
	break;


	case WM_COMMAND :

		if ( (HWND) lparam == hgui )
		{
			n_posix_debug_literal( "%s", n_posix_literal( "Hello!" ) );
		}

	break;


	case WM_CLOSE :

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


