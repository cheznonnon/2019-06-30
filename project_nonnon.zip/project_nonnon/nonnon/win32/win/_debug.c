// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_DEBUG
#define _H_NONNON_WIN32_WIN_DEBUG




#include "../../neutral/posix.c"
#include "../../neutral/string.c"


#include "../registry.c"


#include "../sysinfo/version.c"




// [Mechanism]
//
//	ANSI + ASCII : byte count == character count
//	ANSI + DBCS  : byte count != character count
//      UNICODE      : character count

// [!] : n_win_text_get() needs ( length + NUL('\0') )

#define n_win_text_len( h     )        GetWindowTextLength( h )
#define n_win_text_cch( h     )        GetWindowTextLength( h )
#define n_win_text_get( h,s,l )        GetWindowText( h, s, l )
#define n_win_text_set( h,s   )        SetWindowText( h, s )
#define n_win_text_set_literal( h, s ) SetWindowText( h, n_posix_literal( s ) )

n_posix_char*
n_win_text_new( HWND hgui )
{

	// [!] : n_string_free()/n_string_path_free() a returned string

	int           cch = n_win_text_cch( hgui );
	n_posix_char *str = n_string_new( cch );


	n_win_text_get( hgui, str, cch + 1 );


	return str;
}




// [Mechanism]
//
//	use false first, if not function, then use true

//#define n_win_refresh( h, b ) InvalidateRect( h, NULL, b )

void
n_win_refresh( HWND hwnd, bool strong_mode )
{

	if ( hwnd == NULL ) { return; }
	if ( false == IsWindow( hwnd ) ) { return; }


	InvalidateRect( hwnd, NULL, strong_mode );


	return;
}




#define n_win_hwndprintf_literal( h, f, ... ) n_win_hwndprintf( h, n_posix_literal( f ), ##__VA_ARGS__ )

void
n_win_hwndprintf( HWND hwnd, const n_posix_char *format, ... )
{

	n_posix_char str[ 1024 ];


	va_list vl;


	va_start( vl, format );

	n_posix_vsprintf( str, format, vl );

	va_end( vl );


	n_win_text_set( hwnd, str );


	return;
}

#define n_win_hwnd_find(         h_parent, class ) FindWindowEx( h_parent, NULL, class, NULL )
#define n_win_hwnd_find_literal( h_parent, class ) FindWindowEx( h_parent, NULL, n_posix_literal( class ), NULL )

HWND
n_win_hwnd_toplevel( HWND hwnd )
{

	// [!] : Win95 hasn't GetAncestor()

	while( 1 )
	{
		if ( NULL == GetParent( hwnd ) ) { break; }

		hwnd = GetParent( hwnd );
	}


	return hwnd;
}

HWND
n_win_hwnd_window( HWND hwnd )
{

	while( 1 )
	{//break;
		if ( hwnd == NULL ) { break; }

		if ( false == ( WS_CHILD & GetWindowLong( hwnd, GWL_STYLE ) ) ) { break; }

		 hwnd = GetParent( hwnd );
	}

	return hwnd;
}

void
n_win_mouse_threshold( HWND hwnd, int *ret_x, int *ret_y )
{

	double dx = 1;
	double dy = 1;

	{

		HDC hdc = GetDC( hwnd );

		int dpi_x = GetDeviceCaps( hdc, LOGPIXELSX );
		int dpi_y = GetDeviceCaps( hdc, LOGPIXELSY );
//n_win_hwndprintf_literal( hwnd, "%d %d", dpi_x, dpi_y );

		ReleaseDC( hwnd, hdc );

		dx = (double) dpi_x / 96;
		dy = (double) dpi_y / 96;

	}


	// [!] : 4px will be returned
	//
	//	no change in a high-DPI setting

	const int threshold_sx = GetSystemMetrics( SM_CXDOUBLECLK );
	const int threshold_sy = GetSystemMetrics( SM_CYDOUBLECLK );
//n_win_hwndprintf_literal( hwnd, " %d %d ", threshold_sx, threshold_sy );


	int threshold_x = (int) ( (double) threshold_sx * dx );
	int threshold_y = (int) ( (double) threshold_sy * dy );
//n_win_hwndprintf_literal( hwnd, " %d %d ", threshold_x, threshold_y );


	if ( ret_x != NULL ) { (*ret_x) = threshold_x; }
	if ( ret_y != NULL ) { (*ret_y) = threshold_y; }


	return;
}

void
n_win_desktop_size( s32 *sx, s32 *sy )
{

	// [Mechanism]
	//
	//	[ SXGA 1280x1024 : Classic Theme ]
	//
	//	Taskbar                            :   38
	//	GetSystemMetrics( SM_CXSIZEFRAME ) :    4
	//
	//	GetSystemMetrics( SM_CXMAXIMIZED ) :  988
	//	GetSystemMetrics( SM_CXSCREEN    ) : 1024
	//	GetSystemMetrics( SM_CXMAXTRACK  ) : 1036


	// [!] : this module cannot calculate non-client size
	//
	//	a : use n_win_set() with N_WIN_SET_CALCONLY
	//	b : manual calculation with GetSystemMetrics()
	//
	//	[ WS_OVERLAPPEDWINDOW ]
	//
	//	title bar : SM_CYCAPTION
	//	border    : SM_CXSIZEFRAME and SM_CYSIZEFRAME


	s32 desktop_sx = GetSystemMetrics( SM_CXMAXIMIZED );
	s32 desktop_sy = GetSystemMetrics( SM_CYMAXIMIZED );


	// [!] : magic!

	desktop_sx -= GetSystemMetrics( SM_CXSIZEFRAME ) * 2;
	desktop_sy -= GetSystemMetrics( SM_CYSIZEFRAME ) * 2;


#ifdef _MSC_VER

	// [x] : broken

	desktop_sx -= GetSystemMetrics( SM_CXSIZEFRAME ) * 2;
	desktop_sy -= GetSystemMetrics( SM_CYSIZEFRAME ) * 2;

#endif // #ifdef _MSC_VER


//n_txt_debug_printf_literal( "%d %d", desktop_sx, desktop_sy );

	if ( sx != NULL ) { *sx = desktop_sx; }
	if ( sy != NULL ) { *sy = desktop_sy; }


	return;
}

int
n_win_desktop_bpp( void )
{

	HWND hwnd = GetDesktopWindow();
	HDC  hdc  = GetDC( hwnd );

	int bpp = GetDeviceCaps( hdc, BITSPIXEL );

	ReleaseDC( hwnd, hdc );


	return bpp;
}

bool
n_win_fade_is_on( void )
{

	bool onoff = false;


	if ( n_sysinfo_version_vista_or_later() )
	{
		int n_SPI_GETCLIENTAREAANIMATION = 0x1042;
		SystemParametersInfo( n_SPI_GETCLIENTAREAANIMATION, 0, &onoff, 0 );
	} else {
		SystemParametersInfo(   SPI_GETMENUFADE,            0, &onoff, 0 );
	}


	return onoff;
}

int
n_win_dpi( HWND hwnd )
{

	HDC hdc = GetDC( hwnd );

	int dpi_x = GetDeviceCaps( hdc, LOGPIXELSX );

	ReleaseDC( hwnd, hdc );


	return dpi_x;
}

void
n_win_clear( HWND hwnd, HDC hdc, const RECT *r, int color_id )
{

	// [MSDN] : don't do DeleteObject()

	bool onoff = ( hdc == NULL );

	if ( onoff ) { hdc = GetDC( hwnd ); }

	FillRect( hdc, r, GetSysColorBrush( color_id ) );

	if ( onoff ) { ReleaseDC( hwnd, hdc ); }


	return;
}

void
n_win_box( HWND hwnd, HDC hdc, const RECT *rect, COLORREF color )
{

	// [!] : Classic Theme : alpha value causes black-out

	color &= 0x00ffffff;


	bool onoff = ( hdc == NULL );

	if ( onoff ) { hdc = GetDC( hwnd ); }

	HBRUSH hb = CreateSolidBrush( color );

	FillRect( hdc, rect, hb );

	DeleteObject( hb );

	if ( onoff ) { ReleaseDC( hwnd, hdc ); }


	return;
}

#define n_win_location( h, x, y, sx, sy ) n_win_location_relative( GetParent( h ), h,    x,    y,   sx,   sy )
#define n_win_position( h, x, y         ) n_win_location_relative( GetParent( h ), h,    x,    y, NULL, NULL )
#define n_win_size(     h,       sx, sy ) n_win_location_relative( GetParent( h ), h, NULL, NULL,   sx,   sy )

#define n_win_position_relative( p, h, x, y ) n_win_location_relative( p, h, x, y, NULL, NULL )

void
n_win_location_relative( HWND hwnd_parent, HWND hwnd_child, s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	// [!] : frame border is included

	RECT r; GetWindowRect( hwnd_child, &r );

	POINT pt_tl = { r.left,  r.top    }; ScreenToClient( hwnd_parent, &pt_tl );
	POINT pt_br = { r.right, r.bottom }; ScreenToClient( hwnd_parent, &pt_br );

	if (  x != NULL ) { (* x) = pt_tl.x;           }
	if (  y != NULL ) { (* y) = pt_tl.y;           }
	if ( sx != NULL ) { (*sx) = pt_br.x - pt_tl.x; }
	if ( sy != NULL ) { (*sy) = pt_br.y - pt_tl.y; }


	return;
}




#define N_WIN_CLASS_CCH ( 256 + 1 )

void
n_win_class( HWND hwnd, n_posix_char *classname )
{

	GetClassName( hwnd, classname, N_WIN_CLASS_CCH );

	return;
}

#define n_win_class_is_same_literal( hwnd, classname ) n_win_class_is_same( hwnd, n_posix_literal( classname ) )

bool
n_win_class_is_same( HWND hwnd, const n_posix_char *classname )
{

	// [Needed] : n_string_truncate() : GetClassName() will not touch "class" when hwnd is NULL

	n_posix_char class[ N_WIN_CLASS_CCH ]; n_string_truncate( class );

	n_win_class( hwnd, class );

	if ( n_string_is_same( classname, class ) )
	{
		return true;
	}


	return false;
}


#endif // _H_NONNON_WIN32_WIN_DEBUG

