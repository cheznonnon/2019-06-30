// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File


// [x] : Win95 : not function




#ifndef _H_NONNON_WIN32_WIN_SUBCLASS_STATIC
#define _H_NONNON_WIN32_WIN_SUBCLASS_STATIC




#include "../../gdi/doublebuffer.c"


#include "../../sysinfo/version.c"


#include "../_debug.c"
#include "../rect.c"
#include "../property.c"




LRESULT CALLBACK
n_win_subclass_static_doublebuffer( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const WNDPROC pfunc = (WNDPROC) n_win_property_get_literal( hwnd, "n_win_subclass_static_doublebuffer()" );
	if ( pfunc == NULL ) { return 0; }


	switch( msg ) {


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :
	{

		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );


		RECT r;     GetClientRect( hwnd, &r );
		s32  sx,sy; n_win_rect_expand_size( &r, NULL, NULL, &sx, &sy );

		HDC hdc = n_gdi_doublebuffer_simple_init( hwnd, sx,sy );
		n_gdi_doublebuffer_simple_fill( GetSysColor( COLOR_BTNFACE ) );

		n_win_message_send( hwnd, WM_PRINT, hdc, 0 );

		n_gdi_doublebuffer_simple_visible();

		s32 tx,ty,tsx,tsy; n_win_rect_expand_size( &ps.rcPaint, &tx,&ty,&tsx,&tsy );
		n_gdi_doublebuffer_simple_exit_partial( tx,ty,tsx,tsy );


		EndPaint( hwnd, &ps );

		return 0;

	}
	break;


	} // switch


	return CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
}

void
n_win_subclass_static_init( HWND hgui, const n_posix_char *classname )
{

	if ( false == n_string_is_same_literal( "STATIC", classname ) ) { return; }


	//n_win_refresh( hgui, true );

#ifdef _WIN64

	SetWindowSubclass( hgui, n_win_subclass_static_doublebuffer, 0, 0 );

#else  // #ifdef _WIN64]

	n_win_property_init_literal
	(
		hgui,
		"n_win_subclass_static_doublebuffer()",
		(int) n_win_gui_subclass_set( hgui, n_win_subclass_static_doublebuffer )
	);

#endif // #ifdef _WIN64


	return;
}


#endif // _H_NONNON_WIN32_WIN_SUBCLASS_STATIC

