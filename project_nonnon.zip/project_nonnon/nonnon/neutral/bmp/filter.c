// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_BMP_FILTER
#define _H_NONNON_NEUTRAL_BMP_FILTER




#include "./color.c"
#include "./draw.c"
#include "./transform.c"




#define n_bmp_flush_antialias( bmp, blend ) \
	n_bmp_antialias( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), blend )

void
n_bmp_antialias( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, double blend )
{

	if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }


	n_bmp target; n_bmp_zero( &target ); n_bmp_1st_fast( &target, sx,sy );

	n_bmp_fastcopy( bmp,&target, x,y,sx,sy, 0,0 );


	s32 tx = 0;
	s32 ty = 0;
	while( 1 )
	{

		u32 color = n_bmp_antialias_pixel( bmp, x + tx, y + ty, blend );

		if ( false == n_bmp_is_trans( color ) )
		{
			n_bmp_ptr_set_fast( &target, tx,ty, color );
		}


		tx++;
		if ( tx >= sx ) 
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}

	}


	n_bmp_fastcopy( &target,bmp, 0,0,sx,sy, x,y );

	n_bmp_free( &target );


	return;
}

#define n_bmp_flush_contrast( bmp, param ) \
	n_bmp_contrast( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), param )

void
n_bmp_contrast( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, int param )
{

	if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }


	n_bmp target; n_bmp_zero( &target ); n_bmp_1st_fast( &target, sx,sy );

	n_bmp_fastcopy( bmp,&target, x,y,sx,sy, 0,0 );


	s32 tx = 0;
	s32 ty = 0;
	while( 1 )
	{

		u32 color; n_bmp_ptr_get_fast( &target, tx,ty, &color );

		if ( false == n_bmp_is_trans( color ) )
		{
			color = n_bmp_contrast_pixel( color, param );
			n_bmp_ptr_set_fast( &target, tx,ty, color );
		}


		tx++;
		if ( tx >= sx ) 
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}

	}


	n_bmp_fastcopy( &target,bmp, 0,0,sx,sy, x,y );

	n_bmp_free( &target );


	return;
}

#define n_bmp_flush_sharpen( bmp, blend ) \
	n_bmp_sharpen( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), blend )

void
n_bmp_sharpen( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, double blend )
{

	if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }


	n_bmp target; n_bmp_zero( &target ); n_bmp_1st_fast( &target, sx,sy );

	n_bmp_fastcopy( bmp,&target, x,y,sx,sy, 0,0 );


	s32 tx = 0;
	s32 ty = 0;
	while( 1 )
	{

		u32 color = n_bmp_sharpen_pixel( bmp, x + tx, y + ty, blend );

		if ( false == n_bmp_is_trans( color ) )
		{
			n_bmp_ptr_set_fast( &target, tx,ty, color );
		}


		tx++;
		if ( tx >= sx ) 
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}

	}


	n_bmp_fastcopy( &target,bmp, 0,0,sx,sy, x,y );

	n_bmp_free( &target );


	return;
}

#define n_bmp_flush_gamma( bmp, gamma ) \
	n_bmp_gamma( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), gamma )

void
n_bmp_gamma( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, double gamma )
{

	// [Mechanism]
	//
	//	gamma = 0.0 : black
	//	gamma = 1.0 : nothing to do
	//	gamma = 2.0 : white


	s32 tx,ty;
	u32 color;


	if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }


	// [!] : nothing to do

	if ( gamma == 1.0 ) { return; }


	tx = ty = 0;
	while( 1 )
	{

		n_bmp_ptr_get_fast( bmp, tx + x, ty + y, &color );

		if ( false == n_bmp_is_trans( color ) )
		{
			color = n_bmp_gamma_pixel( color, gamma );
			n_bmp_ptr_set_fast( bmp, tx + x, ty + y, color );
		}


		tx++;
		if ( tx >= sx )
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}
	}


	return;
}

#define N_BMP_COPY_MIRROR_NONE             N_BMP_MIRROR_NONE
#define N_BMP_COPY_MIRROR_LEFTSIDE_RIGHT   N_BMP_MIRROR_LEFTSIDE_RIGHT
#define N_BMP_COPY_MIRROR_UPSIDE_DOWN      N_BMP_MIRROR_UPSIDE_DOWN
#define N_BMP_COPY_MIRROR_ROTATE180        N_BMP_MIRROR_ROTATE180

#define N_BMP_COPY_ROTATE_NONE             N_BMP_ROTATE_NONE
#define N_BMP_COPY_ROTATE_LEFT             N_BMP_ROTATE_LEFT
#define N_BMP_COPY_ROTATE_RIGHT            N_BMP_ROTATE_RIGHT

#define n_bmp_mirrorcopy( f,t, fx,fy, fsx,fsy, tx,ty,      m       ) \
	n_bmp_copy(       f,t, fx,fy, fsx,fsy, tx,ty, 0.0, m, 0, 0 )

#define n_bmp_rotatecopy( f,t, fx,fy, fsx,fsy, tx,ty,         r    ) \
	n_bmp_copy(       f,t, fx,fy, fsx,fsy, tx,ty, 0.0, 0, r, 0 )

#define n_bmp_smoothcopy( f,t, fx,fy, fsx,fsy, tx,ty,            s ) \
	n_bmp_copy(       f,t, fx,fy, fsx,fsy, tx,ty, 0.0, 0, 0, s )

#define n_bmp_flush_copy( fr,to,                                         blend, mirror, rotate, edge ) \
	n_bmp_copy(       fr,to, 0,0,N_BMP_SX( fr ),N_BMP_SY( fr ), 0,0, blend, mirror, rotate, edge )

#define n_bmp_flush_mirrorcopy( f,t,      m       ) \
	n_bmp_flush_copy(       f,t, 0.0, m, 0, 0 )

#define n_bmp_flush_rotatecopy( f,t,         r    ) \
	n_bmp_flush_copy(       f,t, 0.0, 0, r, 0 )

#define n_bmp_flush_smoothcopy( f,t,            s ) \
	n_bmp_flush_copy(       f,t, 0.0, 0, 0, s )

// internal
void
n_bmp_copy
(
	const n_bmp *fr, n_bmp *to,
	s32 fx, s32 fy, s32 fsx, s32 fsy,
	s32 tx, s32 ty,
	double blend,
	int    mirror,
	int    rotate,
	int    edge
)
{

	if ( n_bmp_error_clipping( fr,to, &fx,&fy,&fsx,&fsy, &tx,&ty ) ) { return; }


	const double coef_edge = 1.0 / 9.0;


	s32 bmpsx = N_BMP_SX( fr );
	s32 bmpsy = N_BMP_SY( fr );


	n_bmp target; n_bmp_zero( &target );

	if (
		( mirror == N_BMP_COPY_MIRROR_NONE )
		&&
		( rotate == N_BMP_COPY_ROTATE_NONE )
	)
	{

		n_bmp_1st_fast( &target, bmpsx,bmpsy );
		n_bmp_fastcopy( fr, &target, 0,0,bmpsx,bmpsy, 0,0 );

	} else {

		if ( bmpsx == bmpsy )
		{

			n_bmp b; n_bmp_carboncopy( fr, &b );

			if ( mirror != N_BMP_COPY_MIRROR_NONE )
			{
				n_bmp_flush_mirror( &b, mirror );
			}

			if ( rotate != N_BMP_COPY_ROTATE_NONE )
			{
				n_bmp_rotate( &b, rotate );
			}

			n_bmp_1st_fast( &target, bmpsx,bmpsy );
			n_bmp_fastcopy( &b, &target, 0,0,bmpsx,bmpsy, 0,0 );

			n_bmp_free( &b );

		} else {

			n_bmp b; n_bmp_carboncopy( fr, &b );

			if ( mirror != N_BMP_COPY_MIRROR_NONE )
			{
				n_bmp_flush_mirror( &b, mirror );
			}

			if ( rotate != N_BMP_COPY_ROTATE_NONE )
			{
				// [x] : not supported
				//n_bmp_rotate( &b, rotate );
			}

			n_bmp_1st_fast( &target, bmpsx,bmpsy );
			n_bmp_fastcopy( &b, &target, 0,0,bmpsx,bmpsy, 0,0 );

			n_bmp_free( &b );

		}

	}


	bool write_needed = false;


	s32 x = 0;
	s32 y = 0;
	while( 1 )
	{

		int edge_count;
		if ( n_bmp_edge_detect( &target, fx + x, fy + y, edge, &edge_count ) )
		{

			u32 f,t; n_bmp_ptr_get_fast( &target, fx + x, fy + y, &f );

			if ( edge & N_BMP_EDGE_INNER )
			{
				f = n_bmp_antialias_pixel( &target, fx + x, fy + y, 1.0 );
			} else {
				f = n_bmp_antialias_pixel( to, tx + x, ty + y, 1.0 );
			}

			if ( false == n_bmp_is_trans( f ) )
			{
				n_bmp_ptr_get_fast( to, tx + x, ty + y, &t );

				double d = (double) edge_count * coef_edge * ( 1.0 - blend );

				t = n_bmp_blend_pixel( t,f, d );

				n_bmp_ptr_set_fast( to, tx + x, ty + y, t );
			}

		} else {

			u32 color = n_bmp_composite_pixel_fast( &target, to, fx + x, fy + y, tx + x, ty + y, blend, &write_needed );

			if ( write_needed )
			{
				n_bmp_ptr_set_fast( to, tx + x, ty + y, color );
			}

		}


		x++;
		if ( x >= fsx )
		{

			x = 0;

			y++;
			if ( y >= fsy ) { break; }
		}
	}


	n_bmp_free( &target );


	return;
}

#define n_bmp_transcopy( f,t, fx,fy, fsx,fsy, tx,ty      ) \
        n_bmp_blendcopy( f,t, fx,fy, fsx,fsy, tx,ty, 0.0 )

#define n_bmp_flush_blendcopy( f,t, a ) n_bmp_blendcopy( f,t, 0,0, N_BMP_SX( f ),N_BMP_SY( f ), 0,0, a )
#define n_bmp_flush_transcopy( f,t    ) n_bmp_flush_blendcopy( f,t, 0.0 )

typedef struct {

	const n_bmp  *bmp_f;
	      n_bmp  *bmp_t;
	      s32     fx,fy,fsx,fsy, tx,ty;
	      double  blend;
	      s32     oy;

} n_bmp_blendcopy_thread_struct;

void
n_bmp_blendcopy_thread_main( n_bmp_blendcopy_thread_struct *p )
{

	bool write_needed = false;


	s32 x = 0;
	s32 y = 0;
	while( 1 )
	{

		u32 color = n_bmp_composite_pixel_fast
		(
			p->bmp_f, p->bmp_t,
			p->fx + x, p->fy + y, p->tx + x, p->ty + p->oy + y, 
			p->blend,
			&write_needed
		);

		if ( write_needed )
		{
			n_bmp_ptr_set_fast( p->bmp_t, p->tx + x, p->ty + p->oy + y, color );
		}


		x++;
		if ( x >= p->fsx )
		{

			x = 0;

			y++;
			if ( y >= p->fsy ) { break; }
		}
	}

	return;
}

#ifdef N_POSIX_PLATFORM_WINDOWS

DWORD WINAPI
n_bmp_blendcopy_thread( LPVOID lpParameter )
{

	n_bmp_blendcopy_thread_main( (void*) lpParameter );

	return 0;
}

#endif // #ifdef N_POSIX_PLATFORM_WINDOWS

// internal
void
n_bmp_blendcopy
(
	const n_bmp *fr, n_bmp *to,
	s32 fx, s32 fy, s32 fsx, s32 fsy,
	s32 tx, s32 ty,
	double blend
)
{

	// [Mechanism] : simple/original/faster version of n_bmp_copy()
	//
	//	300% faster than n_bmp_copy()


	if ( n_bmp_error_clipping( fr,to, &fx,&fy,&fsx,&fsy, &tx,&ty ) ) { return; }


#ifdef N_POSIX_PLATFORM_WINDOWS

	// [x] : Win9x : can run but not working

	if (
//(0)&&
		( n_posix_multithread_onoff() )
		&&
		( fsy > n_posix_multithread_core_count )
		&&
		( ( fsx * fsy ) >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_bmp_blendcopy() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = true;


		int cores = n_posix_multithread_core_count;


		HANDLE                        *h = n_memory_new( cores * sizeof( HANDLE                        ) );
		n_bmp_blendcopy_thread_struct *p = n_memory_new( cores * sizeof( n_bmp_blendcopy_thread_struct ) );


		s32 slice = fsy / cores;


		size_t i = 0;
		while( 1 )
		{

			n_bmp_blendcopy_thread_struct tmp = { fr,to, fx,fy + ( i * slice ),fsx,slice, tx,ty, blend, i * slice };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_bmp_blendcopy_thread_struct ) );

			if ( i == ( cores - 1 ) ) { p[ i ].fsy += fsy % cores; }

			h[ i ] = CreateThread( 0, 0, n_bmp_blendcopy_thread, &p[ i ], 0, NULL );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			WaitForSingleObject( h[ i ], INFINITE );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			CloseHandle( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_bmp_blendcopy_thread_struct p = { fr,to, fx,fy,fsx,fsy, tx,ty, blend, 0 };

		n_bmp_blendcopy_thread_main( &p );

	}

#else  // #ifdef N_POSIX_PLATFORM_WINDOWS

	n_bmp_blendcopy_thread_struct p = { fr,to, fx,fy,fsx,fsy, tx,ty, blend, 0 };

	n_bmp_blendcopy_thread_main( &p );

#endif // #ifdef N_POSIX_PLATFORM_WINDOWS


	return;
}

void
n_bmp_flush_monochrome( n_bmp *bmp )
{

	if ( n_bmp_error( bmp ) ) { return; }


	s32  x = 0;
	s32  y = 0;
	s32 sx = N_BMP_SX( bmp );
	s32 sy = N_BMP_SY( bmp );
	while( 1 )
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );


		// [!] : alpha is reserved

		if ( n_bmp_transparent_onoff )
		{

			if ( color != n_bmp_trans )
			{
				n_bmp_ptr_set_fast( bmp, x,y, n_bmp_white | ( color & 0xff000000 ) );
			}

		} else {

			if ( color != n_bmp_white )
			{
				n_bmp_ptr_set_fast( bmp, x,y, n_bmp_black | ( color & 0xff000000 ) );
			}

		}


		x++;
		if ( x >= sx )
		{

			x = 0;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}

void
n_bmp_flush_replacer( n_bmp *bmp, u32 color_from, u32 color_to )
{

	if ( n_bmp_error( bmp ) ) { return; }


	s32  x = 0;
	s32  y = 0;
	s32 sx = N_BMP_SX( bmp );
	s32 sy = N_BMP_SY( bmp );
	while( 1 )
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		if ( false == n_bmp_is_trans( color ) )
		{
			if ( color == color_from )
			{
				n_bmp_ptr_set_fast( bmp, x,y, color_to );
			}
		}


		x++;
		if ( x >= sx )
		{

			x = 0;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}

void
n_bmp_flush_grayscale( n_bmp *bmp )
{

	if ( n_bmp_error( bmp ) ) { return; }


	s32  x = 0;
	s32  y = 0;
	s32 sx = N_BMP_SX( bmp );
	s32 sy = N_BMP_SY( bmp );
	while( 1 )
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		if ( false == n_bmp_is_trans( color ) )
		{
			n_bmp_ptr_set_fast( bmp, x,y, n_bmp_grayscale_pixel( color ) );
		}


		x++;
		if ( x >= sx )
		{

			x = 0;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}

#define n_bmp_flush_tweaker( bmp, a, r, g, b ) \
	n_bmp_tweaker( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), a, r, g, b )

void
n_bmp_tweaker( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, int a, int r, int g, int b )
{

	// [!] : nothing to do

	if ( 0 == n_bmp_argb( a,r,g,b ) ) { return; }


	if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }

	s32 tx = 0;
	s32 ty = 0;
	while( 1 )
	{

		u32 color; n_bmp_ptr_get_fast( bmp, tx + x, ty + y, &color );

		if ( false == n_bmp_is_trans( color ) )
		{

			int aa = n_bmp_clamp_channel( n_bmp_a( color ) + a );
			int rr = n_bmp_clamp_channel( n_bmp_r( color ) + r );
			int gg = n_bmp_clamp_channel( n_bmp_g( color ) + g );
			int bb = n_bmp_clamp_channel( n_bmp_b( color ) + b );

			color = n_bmp_argb( aa,rr,gg,bb );

			n_bmp_ptr_set_fast( bmp, tx + x, ty + y, color );

		}


		tx++;
		if ( tx >= sx )
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}
	}


	return;
}

#define n_bmp_flush_hue_wheel( bmp, h ) n_bmp_flush_tweaker_hsl( bmp, h, 0, 0 )
#define n_bmp_flush_vividness( bmp, s ) n_bmp_flush_tweaker_hsl( bmp, 0, s, 0 )
#define n_bmp_flush_lightness( bmp, l ) n_bmp_flush_tweaker_hsl( bmp, 0, 0, l )

void
n_bmp_flush_tweaker_hsl( n_bmp *bmp, int hue, int saturation, int lightness )
{

	if ( n_bmp_error( bmp ) ) { return; }


	// [!] : nothing to do

	if ( ( hue == 0 )&&( saturation == 0 )&&( lightness == 0 ) ) { return; }


	s32  x = 0;
	s32  y = 0;
	s32 sx = N_BMP_SX( bmp );
	s32 sy = N_BMP_SY( bmp );
	while( 1 )
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		color = n_bmp_hsl_tweak_pixel( color, hue, saturation, lightness );

		n_bmp_ptr_set_fast( bmp, x,y, color );


		x++;
		if ( x >= sx )
		{

			x = 0;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}

#define n_bmp_flush_mixer( bmp, color_mix, blend ) \
	n_bmp_mixer( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), color_mix, blend )

void
n_bmp_mixer( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, u32 color_mix, double blend )
{

	if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }

	s32 tx = 0;
	s32 ty = 0;
	while( 1 )
	{

		u32 color_f; n_bmp_ptr_get_fast( bmp, tx + x, ty + y, &color_f );

		if ( false == n_bmp_is_trans( color_f ) )
		{
			u32 color_t = n_bmp_blend_pixel( color_f, color_mix, blend );
			if ( color_f != color_t )
			{
				n_bmp_ptr_set_fast( bmp, tx + x, ty + y, color_t );
			}
		}


		tx++;
		if ( tx >= sx )
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}
	}


	return;
}

#define n_bmp_flush_reducer( bmp, factor ) \
	n_bmp_reducer( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), factor )

// internal
inline int
n_bmp_reducer_helper( int v, int v_min, int v_mid, int v_max, int factor )
{

	if ( v == v_max ) { return n_bmp_simplify_channel( v_max, factor * 1 ); }
	if ( v == v_min ) { return n_bmp_simplify_channel( v_min, factor * 4 ); }

	return v_mid;
}

void
n_bmp_reducer( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, int factor )
{

	// [!] : nothing to do

	if ( factor == 0 ) { return; }


	if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }


	// [!] : for backward compatibility

	factor = abs( factor );


	s32 tx = 0;
	s32 ty = 0;
	while( 1 )
	{

		u32 color; n_bmp_ptr_get_fast( bmp, tx + x, ty + y, &color );

		int a = n_bmp_a( color );
		int r = n_bmp_r( color );
		int g = n_bmp_g( color );
		int b = n_bmp_b( color );

		if ( n_bmp_moire_detect( x,y, 1 ) )
		{

			int max = n_posix_max( r, n_posix_max( g, b ) );
			int min = n_posix_min( r, n_posix_min( g, b ) );
			int mid = ( r + g + b ) / 3;

			// [!] : alpha is reserved
			r = n_bmp_reducer_helper( r, min, mid, max, 2 * factor );
			g = n_bmp_reducer_helper( g, min, mid, max, 1 * factor );
			b = n_bmp_reducer_helper( b, min, mid, max, 4 * factor );

		} else {

			// [!] : alpha is reserved
			r = n_bmp_simplify_channel( r, factor );
			g = n_bmp_simplify_channel( g, factor );
			b = n_bmp_simplify_channel( b, factor );

		}

		n_bmp_ptr_set_fast( bmp, tx + x, ty + y, n_bmp_argb( a,r,g,b ) );


		tx++;
		if ( tx >= sx )
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}
	}


	return;
}

#define n_bmp_rasterizer( fr, to, tx, ty, color, clear ) n_bmp_rasterizer_main( fr, to, tx, ty, NULL, color, clear )

void
n_bmp_rasterizer_main( n_bmp *fr, n_bmp *to, s32 tx, s32 ty, n_bmp *bmp_color, u32 color, bool clear_onoff )
{

	// [Mechanism]
	//
	//	fr          : gray-scaled + antialiased bitmap
	//	to          : canvas
	//	color       : color to mix
	//	clear_onoff : use ClearType-like technique
	//
	//	alpha value is not supported for performance


	if ( n_bmp_error( fr ) ) { return; }
	if ( n_bmp_error( to ) ) { return; }

	if ( n_bmp_is_trans( color ) ) { return; }


	// [!] : cache for performance : +5%

	double value = 0;
	double blend = 0;


	s32  x = 0;
	s32  y = 0;
	s32 sx = N_BMP_SX( fr );
	s32 sy = N_BMP_SY( fr );

	if ( clear_onoff )
	{

		//const u32    color_red     = n_bmp_rgb( 255,  0,  0 );
		const u32    color_blue    = n_bmp_rgb(   0,  0,255 );
		const u32    color_green   = n_bmp_rgb(   0,255,  0 );
		const u32    color_cyan    = n_bmp_rgb(   0,255,255 );
		const u32    color_magenta = n_bmp_rgb( 255,  0,255 );
		//const u32    color_yellow  = n_bmp_rgb( 255,255,  0 );

		const u32    color_default = 0xffffffff;
		const u32    color_u       = color_green;
		const u32    color_d       = color_blue;
		const u32    color_l       = color_magenta;
		const u32    color_r       = color_cyan;
		const int    cutoff        = 128;
		const double ratio         = 0.25;

		while( 1 )
		{

			u32 f,t;
			n_bmp_ptr_get_fast( fr, x,y, &f );

			if (
				( false == n_bmp_is_trans( f ) )
				&&
				( false == n_bmp_ptr_get( to, tx + x, ty + y, &t ) )
			)
			{

				int v = n_bmp_r( f );
				if ( v != value )
				{
					value = v;
					blend = value * n_bmp_coeff_channel;
				}


				u32 tt;
				if ( bmp_color != NULL )
				{
					u32 c; n_bmp_ptr_get_fast( bmp_color, x,y, &c );
					tt = n_bmp_blend_pixel( t,     c, blend );
				} else {
					tt = n_bmp_blend_pixel( t, color, blend );
				}


				// [!] : Engine

				u32 u = color_default; n_bmp_ptr_get( fr, x, y - 1, &u );
				u32 d = color_default; n_bmp_ptr_get( fr, x, y + 1, &d );

				bool is_u = ( cutoff > (int) n_bmp_r( u ) );
				bool is_d = ( cutoff > (int) n_bmp_r( d ) );

				if ( ( is_u )&&( is_d ) )
				{
					//
				} else
				if ( is_u )
				{
					tt = n_bmp_blend_pixel( tt, color_u, ratio );
				} else
				if ( is_d )
				{
					tt = n_bmp_blend_pixel( tt, color_d, ratio );
				}


				u32 l = color_default; n_bmp_ptr_get( fr, x - 1, y, &l );
				u32 r = color_default; n_bmp_ptr_get( fr, x + 1, y, &r );

				bool is_l = ( cutoff > (int) n_bmp_r( l ) );
				bool is_r = ( cutoff > (int) n_bmp_r( r ) );

				if ( ( is_l )&&( is_r ) )
				{
					//
				} else
				if ( is_l )
				{
					tt = n_bmp_blend_pixel( tt, color_l, ratio );
				} else
				if ( is_r )
				{
					tt = n_bmp_blend_pixel( tt, color_r, ratio );
				}


				if ( t != tt ) { n_bmp_ptr_set_fast( to, tx + x, ty + y,  tt ); }

			}


			x++;
			if ( x >= sx )
			{

				x = 0;

				y++;
				if ( y >= sy ) { break; }
			}
		}

	} else {

		while( 1 )
		{

			u32 f,t;
			n_bmp_ptr_get_fast( fr, x,y, &f );

			if (
				( false == n_bmp_is_trans( f ) )
				&&
				( false == n_bmp_ptr_get( to, tx + x, ty + y, &t ) )
			)
			{

				int v = n_bmp_r( f );
				if ( v != value )
				{
					value = v;
					blend = value * n_bmp_coeff_channel;
				}


				u32 tt;
				if ( bmp_color != NULL )
				{
					u32 c; n_bmp_ptr_get_fast( bmp_color, x,y, &c );
					tt = n_bmp_blend_pixel( t,     c, blend );
				} else {
					tt = n_bmp_blend_pixel( t, color, blend );
				}


				if ( t != tt ) { n_bmp_ptr_set_fast( to, tx + x, ty + y,  tt ); }

			}


			x++;
			if ( x >= sx )
			{

				x = 0;

				y++;
				if ( y >= sy ) { break; }
			}
		}

	}


	return;
}

void
n_bmp_cornermask( n_bmp *bmp, s32 round_size, s32 frame_size, u32 bg )
{

	if ( n_bmp_error( bmp ) ) { return; }

	if ( round_size == 0 ) { return; }


	const s32 sx = N_BMP_SX( bmp );
	const s32 sy = N_BMP_SY( bmp );


	n_bmp b; n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx,sy ); n_bmp_flush( &b, n_bmp_white );

	s32 tx  = frame_size;
	s32 ty  = frame_size;
	s32 tsx = sx - ( frame_size * 2 );
	s32 tsy = sy - ( frame_size * 2 );

	n_bmp_roundrect( &b, tx,ty,tsx,tsy, n_bmp_black, round_size );

	n_bmp_rasterizer( &b, bmp, 0,0, bg, false );

	n_bmp_free( &b );


	return;
}


#endif // _H_NONNON_NEUTRAL_BMP_FILTER

