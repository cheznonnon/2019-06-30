// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_BMP_DETECT
#define _H_NONNON_NEUTRAL_BMP_DETECT




#include <math.h>




#include "./_error.c"
#include "./_transparent.c"


#include "../type.c"




bool
n_bmp_grayscale_detect( u32 color )
{

	// [!] : alpha is not used

	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );


	return ( ( r == g )&&( g == b ) );
}

#define n_bmp_circle_detect(  x,y,r     ) n_bmp_ellipse_detect_coeff( x,y, r, r, NULL )
#define n_bmp_ellipse_detect( x,y,rx,ry ) n_bmp_ellipse_detect_coeff( x,y,rx,ry, NULL )

bool
n_bmp_ellipse_detect_coeff( s32 x, s32 y, s32 rx, s32 ry, double *coeff )
{

	x = abs( x );
	y = abs( y );

	if ( ( rx < x )||( ry < y ) )
	{
		if ( coeff != NULL ) { (*coeff) = 0.0; }
		return false;
	}


	double dx = x * x;
	double dy = y * y;


	double drx, dry;

	if ( rx == ry )
	{
		drx = dry = rx * rx;
	} else {
		drx = rx * rx;
		dry = ry * ry;
	}


	dx /= drx;
	dy /= dry;


	// [!] : too blurry

	// [!] : this is slightly inaccurate

	if ( coeff != NULL )
	{
		double antiblur = (double) n_posix_min_s32( rx,ry ) / 2;
		(*coeff) = ( 1.0 - ( dx + dy ) ) * antiblur;
	}


	return ( ( dx + dy ) <= 1.0 );
}

#define n_bmp_roundrect_detect( x,y,sx,sy,r ) n_bmp_roundrect_detect_coeff( x,y,sx,sy,r, NULL )

bool
n_bmp_roundrect_detect_coeff( s32 x, s32 y, s32 sx, s32 sy, s32 r, double *coeff )
{

	// [!] : 1px border is made without this

	 x += 1;
	 y += 1;
	sx += 2;
	sy += 2;


	s32 x_min = r;
	s32 y_min = r;
	s32 x_max = sx - 1 - r;
	s32 y_max = sy - 1 - r;


	if ( x <= x_min ) { x -= x_min; } else if ( x >= x_max ) { x -= x_max; } else { x = 0; }
	if ( y <= y_min ) { y -= y_min; } else if ( y >= y_max ) { y -= y_max; } else { y = 0; }


	double dx = x * x;
	double dy = y * y;
	double dr = r * r;


	dx /= dr;
	dy /= dr;


	// [!] : too blurry

	if ( coeff != NULL )
	{
		double antiblur = (double) r / 1.5;
		(*coeff) = ( 1.0 - ( dx + dy ) ) * antiblur;
	}


	return ( ( dx + dy ) <= 1.0 );
}

bool
n_bmp_moire_detect( s32 x, s32 y, int pattern )
{

	if ( pattern == 0 )
	{

		return true;

	} else
	if ( pattern == 1 )
	{

		// oxoxo
		// xoxox
		// oxoxo

		x &= 1;
		y &= 1;

		if (
			( ( x == 0 )&&( y != 0 ) )
			||
			( ( x != 0 )&&( y == 0 ) )
		)
		{
			return true;
		}

	} else
	if ( pattern == 2 )
	{

		// xoxox
		// oxoxo
		// xoxox

		x &= 1;
		y &= 1;

		if (
			( ( x == 0 )&&( y == 0 ) )
			||
			( ( x != 0 )&&( y != 0 ) )
		)
		{
			return true;
		}
	}


	return false;
}

s32
n_bmp_bezier_detect( s32 f, s32 m, s32 t, double step )
{

	// [Mechanism]
	//
	//	f    : from       : 0
	//	m    : control    : size / 2
	//	t    : to         : size
	//	step : 0.0 to 1.0 : 1 / size for unit
	//
	//	this module cannot draw continuous line
	//	use n_bmp_line() to draw


	double a  = (double) 1.0 - step;
	double b  = (double)       step;
	double p1 = (double) ( a * a     ) * f;
	double p2 = (double) ( 2 * a * b ) * m;
	double p3 = (double) ( b * b     ) * t;


	return (s32) ( (double) p1 + p2 + p3 ); 
}

#define N_BMP_EDGE_NONE  ( 0 << 0 )
#define N_BMP_EDGE_INNER ( 1 << 0 )
#define N_BMP_EDGE_OUTER ( 1 << 1 )
#define N_BMP_EDGE_INOUT ( N_BMP_EDGE_INNER | N_BMP_EDGE_OUTER )
#define N_BMP_EDGE_MASK  ( N_BMP_EDGE_INOUT | 0xffff0000 )
#define N_BMP_EDGE_U     ( 1 << 2 )
#define N_BMP_EDGE_D     ( 1 << 3 )
#define N_BMP_EDGE_L     ( 1 << 4 )
#define N_BMP_EDGE_R     ( 1 << 5 )
#define N_BMP_EDGE_UL    ( 1 << 6 )
#define N_BMP_EDGE_UR    ( 1 << 7 )
#define N_BMP_EDGE_DL    ( 1 << 8 )
#define N_BMP_EDGE_DR    ( 1 << 9 )
#define N_BMP_EDGE_ALL   ( ~N_BMP_EDGE_MASK )
#define N_BMP_EDGE_CROSS ( N_BMP_EDGE_U | N_BMP_EDGE_D | N_BMP_EDGE_L | N_BMP_EDGE_R )

// internal
s32
n_bmp_edge_detect_check( n_bmp *bmp, s32 fx, s32 fy )
{

	s32 x,y,tx,ty;
	u32 color;
	s32 edge, count;
	int i, ret;


	if ( n_bmp_error( bmp ) ) { return 0; }


	// Center

	ret = n_bmp_ptr_get( bmp, fx,fy, &color );
	if ( ret == false )
	{

		if ( n_bmp_is_trans( color ) )
		{
			edge = N_BMP_EDGE_OUTER;
		} else {
			edge = N_BMP_EDGE_INNER;
		}

	} else {

		edge = N_BMP_EDGE_OUTER;

	}


	x = y = -1;


	i = ret = count = 0;
	while( 1 )
	{

		tx = fx + x;
		ty = fy + y;

		ret = n_bmp_ptr_get( bmp, tx,ty, &color );
		if ( ret == 0 )
		{

			if (
				( ( edge & N_BMP_EDGE_INNER )&&( false != n_bmp_is_trans( color ) ) )
				||
				( ( edge & N_BMP_EDGE_OUTER )&&( false == n_bmp_is_trans( color ) ) )
			)
			{

				count++;

				if ( i == 0 ) { edge |= N_BMP_EDGE_UL; } else
				if ( i == 1 ) { edge |= N_BMP_EDGE_U;  } else
				if ( i == 2 ) { edge |= N_BMP_EDGE_UR; } else
				if ( i == 3 ) { edge |= N_BMP_EDGE_L;  } else
				// ( i == 4 ) : center
				if ( i == 5 ) { edge |= N_BMP_EDGE_R;  } else
				if ( i == 6 ) { edge |= N_BMP_EDGE_DL; } else
				if ( i == 7 ) { edge |= N_BMP_EDGE_D;  } else
				if ( i == 8 ) { edge |= N_BMP_EDGE_DR; }

			}

		}


		i++;


		x++;
		if ( x >= 2 )
		{

			x = -1;

			y++;
			if ( y >= 2 ) { break; }
		}
	}


	if ( edge & N_BMP_EDGE_INNER ) { count = 9 - count; }


	return edge | ( count << 16 );
}

bool
n_bmp_edge_detect( n_bmp *bmp, s32 x, s32 y, s32 edge, int *count )
{

	if ( edge == N_BMP_EDGE_NONE ) { return false; }


	s32 check = n_bmp_edge_detect_check( bmp, x,y );

	if ( count != NULL )
	{
		(*count) = check >> 16;
	}


	// [!] : different type

	if (
		( ( edge & N_BMP_EDGE_INOUT ) != N_BMP_EDGE_INOUT )
		&&
		( ( edge & N_BMP_EDGE_INOUT ) != ( check & N_BMP_EDGE_INOUT ) )
	)
	{
		return 0;
	}


	return ( ( edge & N_BMP_EDGE_ALL ) & ( check & N_BMP_EDGE_ALL ) );
}


#endif //_H_NONNON_NEUTRAL_BMP_DETECT

