// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_BMP_TRANSPARENT
#define _H_NONNON_NEUTRAL_BMP_TRANSPARENT




#include "../posix.c"




#define N_BMP_TRANSPARENT_OFF false
#define N_BMP_TRANSPARENT_ON  true


#define n_bmp_trans n_bmp_black


#define n_bmp_is_trans( color ) ( ( n_bmp_transparent_onoff )&&( color == n_bmp_trans ) )

#define n_bmp_transparent_on()  n_bmp_transparent_onoff = N_BMP_TRANSPARENT_ON
#define n_bmp_transparent_off() n_bmp_transparent_onoff = N_BMP_TRANSPARENT_OFF


static bool n_bmp_transparent_onoff = N_BMP_TRANSPARENT_OFF;




// [!] : for temporary on/off

u32
n_bmp_transparent_change( u32 onoff )
{

	u32 prv = n_bmp_transparent_onoff;


	n_bmp_transparent_onoff = onoff;


	return prv;
}


#endif // _H_NONNON_NEUTRAL_BMP_TRANSPARENT

