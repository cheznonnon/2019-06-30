// Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : don't use "posix.c" in this file




#ifndef _H_NONNON_NEUTRAL_MEMORY
#define _H_NONNON_NEUTRAL_MEMORY




#include "./type.c"


#include <stdlib.h>
#include <string.h>




// [!] : use when logic is safely closed
//
//	a : allocated memory will be overwritten immediately
//	b : allocated memory will be freed in narrow scope

#define n_memory_new_closed  n_memory_new
#define n_memory_free_closed n_memory_free


// Debug Facility : don't use as main release

#ifdef N_MEMORY_DEBUG

static size_t n_memory_refcount = 0;

void*
n_memory_new( size_t byte )
{

	if ( byte == 0 ) { return NULL; }


	void *ret = malloc( byte );

	n_memory_refcount++;


	// [!] : scrambling

	memset( ret, rand(), byte );


	return ret;
}

void
n_memory_free( void *ptr )
{

	if ( ptr == NULL ) { return; }


	free( ptr );

	if ( n_memory_refcount >= 1 ) { n_memory_refcount--; }


	return;
}

void*
n_memory_resize( void* ptr, size_t byte )
{

	// [!] : free() equivalent behavior

	if ( byte == 0 )
	{

		n_memory_free( ptr );

		return NULL;
	}


	void *ret = realloc( ptr, byte );


	// [!] : malloc() equivalent behavior

	if ( ptr == NULL ) { n_memory_refcount++; }


	return ret;
}

#else // #ifdef N_MEMORY_DEBUG


#ifdef _MSC_VER

#define n_memory_resize   realloc
#define n_memory_refcount 0

// [Needed] : VC++ 2017 : break point

void*
n_memory_new( size_t cb )
{

	void *ptr = malloc( cb );

	//memset( ptr, 0, cb );

	return ptr;
}

void
n_memory_free( void *ptr )
{

	if ( ptr != NULL ) { free( ptr ); }

	return;
}

#else  // #ifdef _MSC_VER

#define n_memory_new      malloc
#define n_memory_free     free
#define n_memory_resize   realloc
#define n_memory_refcount 0

#endif // #ifdef _MSC_VER

#endif // #ifdef N_MEMORY_DEBUG




#define n_memory_zero( ptr, byte ) n_memory_padding( ptr, 0, byte )

void
n_memory_padding( void *ptr, char c, size_t byte )
{

	if ( ptr  == NULL ) { return; }
	if ( byte <=    0 ) { return; }


	memset( ptr, c, byte );


	return;
}

void
n_memory_padding_int( int *ptr, int c, size_t count )
{

	// [!] : count = byte / sizeof( int )


	if ( ptr == NULL ) { return; }


	size_t i = 0;
	while( 1 )
	{

		ptr[ i ] = c;

		i++;
		if ( i >= count ) { break; }
	}


	return;
}

bool
n_memory_is_same( const void *a, const void *b, size_t byte )
{

	if ( a    == NULL ) { return 0; }
	if ( b    == NULL ) { return 0; }
	if ( byte ==    0 ) { return 0; }


	return ( 0 == memcmp( a, b, byte ) );
}

void
n_memory_copy( const void *f, void *t, size_t byte )
{

	if ( f    == NULL ) { return; }
	if ( t    == NULL ) { return; }
	if ( byte ==    0 ) { return; }


	//memcpy( t, f, byte );
	memmove( t, f, byte );


	return;
}




void*
n_memory_element_add( void *p, size_t align, size_t count, size_t index )
{

	if ( p == NULL ) { return NULL; }

	if ( align == 0 ) { return NULL; }
	if ( count == 0 ) { return NULL; }

	// [!] : index == count is acceptable

	if ( index > count ) { return NULL; }


	count++;

	size_t  all  = align * count;
	size_t  prev = align * index;
	size_t  next = prev  + align;
	char   *ptr  = (char*) n_memory_resize( p, all );

	if ( next != all )
	{
		n_memory_copy( &ptr[ prev ], &ptr[ next ], all - next );
	}

	n_memory_padding( &ptr[ prev ], 0, align );


	return ptr;
}

void*
n_memory_element_del( void *p, size_t align, size_t count, size_t index )
{

	if ( p == NULL ) { return NULL; }

	if ( align <= 0 ) { return NULL; }
	if ( count <= 0 ) { return NULL; }

	if ( index >= count ) { return NULL; }


	size_t  all  = align * count;
	size_t  prev = align * index;
	size_t  next = prev  + align;
	char   *ptr  = (char*) p;

	if ( prev != all )
	{
		n_memory_copy( &ptr[ next ], &ptr[ prev ], all - next );
	}


	// [!] : malloc() compatible behavior

	p = n_memory_resize( p, all - align );
	if ( p == NULL ) { p = malloc( 0 ); }


	return p;
}

void
n_memory_element_swap( void *p, size_t align, size_t index_1, size_t index_2 )
{

	if ( p == NULL ) { return; }

	if ( align == 0 ) { return; }

	if ( index_1 == index_2 ) { return; }


	index_1 *= align;
	index_2 *= align;

	char *ptr = (char*) p;
	char *elm = (char*) n_memory_new_closed( align );

	n_memory_copy( &ptr[ index_1 ],             elm, align );
	n_memory_copy( &ptr[ index_2 ], &ptr[ index_1 ], align );
	n_memory_copy(             elm, &ptr[ index_2 ], align );

	n_memory_free_closed( elm );


	return;
}


#endif // _H_NONNON_NEUTRAL_MEMORY

