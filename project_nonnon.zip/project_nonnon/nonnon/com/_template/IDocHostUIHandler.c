// Nonnon COM : IDocHostUIHandler
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed


// [!] : CLSID_WebBrowser : HTMLDocument2 has ICustonDoc




#ifndef _H_NONNON_WIN32_COM_IDOCHOSTUIHANDLER
#define _H_NONNON_WIN32_COM_IDOCHOSTUIHANDLER




HRESULT __stdcall
n_IDocHostUIHandler_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{
n_com_debug_IUnknown_QueryInterface( _this, iid, ppvObject );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID d = n_com_guid( n_guid_IID_IDispatch );
	GUID o = n_com_guid( n_guid_IID_IDocHostUIHandler );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &d ) )
		||
		( IsEqualGUID( iid, &o ) )
	)
	{

		if ( ppvObject != NULL ) {  (*ppvObject) = _this; }

		return S_OK;

	}


	return E_NOINTERFACE;
}




HRESULT
n_IDocHostUIHandler_ShowContextMenu
(
	IDocHostUIHandler *_this,
	DWORD              dwID,
	POINT             *ppt,
	IUnknown          *pcmdtReserved,
	IDispatch         *pdispReserved
)
{
n_posix_debug_literal( "IDocHostUIHandler_ShowContextMenu" );


	// [MSDN] : S_OK : no context menu

	return S_OK;


	return S_FALSE;
}

HRESULT
n_IDocHostUIHandler_GetHostInfo( IDocHostUIHandler *_this, DOCHOSTUIINFO *pInfo )
{
n_posix_debug_literal( "IDocHostUIHandler_GetHostInfo" );

	return S_OK;
}

HRESULT
n_IDocHostUIHandler_ShowUI
(
	IDocHostUIHandler       *_this,
	DWORD                    dwID,
	IOleInPlaceActiveObject *pActiveObject,
	IOleCommandTarget       *pCommandTarget,
	IOleInPlaceFrame        *pFrame,
	IOleInPlaceUIWindow     *pDoc
)
{
n_posix_debug_literal( "IDocHostUIHandler_ShowUI : %d", dwID );


	// [x] : crash : S_OK / S_FALSE


	RECT rect;

	pDoc->lpVtbl->SetActiveObject ( pDoc, pActiveObject, NULL );
	pDoc->lpVtbl->GetBorder( pDoc, &rect );

	pActiveObject->lpVtbl->EnableModeless( pActiveObject, TRUE );
	pActiveObject->lpVtbl->OnDocWindowActivate( pActiveObject, TRUE );
	pActiveObject->lpVtbl->OnFrameWindowActivate( pActiveObject, TRUE );
	pActiveObject->lpVtbl->ResizeBorder( pActiveObject, &rect, pDoc, TRUE );

	pFrame->lpVtbl->EnableModeless( pFrame, TRUE );


	return S_OK;
}

HRESULT
n_IDocHostUIHandler_HideUI( IDocHostUIHandler *_this )
{
n_posix_debug_literal( "IDocHostUIHandler_HideUI" );

	return S_OK;
}

HRESULT
n_IDocHostUIHandler_UpdateUI( IDocHostUIHandler *_this )
{
n_posix_debug_literal( "IDocHostUIHandler_UpdateUI" );

	return S_OK;
}

HRESULT
n_IDocHostUIHandler_EnableModeless( IDocHostUIHandler *_this, BOOL fEnable )
{
n_posix_debug_literal( "IDocHostUIHandler_EnableModeless" );

	return S_OK;
}

HRESULT
n_IDocHostUIHandler_OnDocWindowActivate( IDocHostUIHandler *_this, BOOL fActivate )
{
n_posix_debug_literal( "IDocHostUIHandler_OnDocWindowActivate" );

	return S_OK;
}

HRESULT
n_IDocHostUIHandler_OnFrameWindowActivate( IDocHostUIHandler *_this, BOOL fActivate )
{
n_posix_debug_literal( "IDocHostUIHandler_OnFrameWindowActivate" );

	return S_OK;
}

HRESULT
n_IDocHostUIHandler_ResizeBorder( IDocHostUIHandler *_this, LPCRECT prcBorder, IOleInPlaceUIWindow *pUIWindow, BOOL fRameWindow )
{
n_posix_debug_literal( "IDocHostUIHandler_ResizeBorder" );

	return S_FALSE;
}

HRESULT
n_IDocHostUIHandler_TranslateAccelerator( IDocHostUIHandler *_this, LPMSG lpMsg, const GUID *pguidCmdGroup, DWORD nCmdID )
{
n_posix_debug_literal( "IDocHostUIHandler_TranslateAccelerator" );

	return S_FALSE;
}

HRESULT
n_IDocHostUIHandler_GetOptionKeyPath( IDocHostUIHandler *_this, LPOLESTR *pchKey, DWORD dw )
{
n_posix_debug_literal( "IDocHostUIHandler_GetOptionKeyPath" );

	return E_FAIL;
}

HRESULT
n_IDocHostUIHandler_GetDropTarget( IDocHostUIHandler *_this, IDropTarget *pDropTarget, IDropTarget **ppDropTarget )
{
n_posix_debug_literal( "IDocHostUIHandler_GetDropTarget" );

	return E_FAIL;
}

HRESULT
n_IDocHostUIHandler_GetExternal( IDocHostUIHandler *_this, IDispatch **ppDispatch )
{
n_posix_debug_literal( "IDocHostUIHandler_GetExternal" );

	return E_FAIL;
}

HRESULT
n_IDocHostUIHandler_TranslateUrl( IDocHostUIHandler *_this, DWORD dwTranslate, OLECHAR *pchURLIn, OLECHAR **ppchURLOut )
{
n_posix_debug_literal( "IDocHostUIHandler_TranslateUrl" );

	return E_FAIL;
}

HRESULT
n_IDocHostUIHandler_FilterDataObject( IDocHostUIHandler *_this, IDataObject *pDO, IDataObject **ppDORet )
{
n_posix_debug_literal( "IDocHostUIHandler_FilterDataObject" );

	return S_FALSE;
}




const void *n_IDocHostUIHandler_Vtbl[] = {

	n_IDocHostUIHandler_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,

	n_IDocHostUIHandler_ShowContextMenu,
	n_IDocHostUIHandler_GetHostInfo,
	n_IDocHostUIHandler_ShowUI,
	n_IDocHostUIHandler_HideUI,
	n_IDocHostUIHandler_UpdateUI,
	n_IDocHostUIHandler_EnableModeless,
	n_IDocHostUIHandler_OnDocWindowActivate,
	n_IDocHostUIHandler_OnFrameWindowActivate,
	n_IDocHostUIHandler_ResizeBorder,
	n_IDocHostUIHandler_TranslateAccelerator,
	n_IDocHostUIHandler_GetOptionKeyPath,
	n_IDocHostUIHandler_GetDropTarget,
	n_IDocHostUIHandler_GetExternal,
	n_IDocHostUIHandler_TranslateUrl,
	n_IDocHostUIHandler_FilterDataObject,

};


IDocHostUIHandler n_IDocHostUIHandler_instance = { (void*) n_IDocHostUIHandler_Vtbl };




#endif // _H_NONNON_WIN32_COM_IDOCHOSTUIHANDLER

