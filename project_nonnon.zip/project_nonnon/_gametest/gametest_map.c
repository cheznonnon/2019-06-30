// Nonnon Game Test
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	bool       input;

	n_game_map map;

} n_gametest_map;




void
n_gametest_map_init( n_gametest_map *m )
{

	m->input = true;

	n_game_map_init
	(
		&m->map,
		n_posix_literal( "./gametest/map.bmp"  ),
		n_posix_literal( "./gametest/chip.bmp" ),
		32,32,
		N_GAME_MAP_MODE_STOP,
		&game.bmp
	);

	n_game_map_safemode = true;


	return;
}

void
n_gametest_map_loop( n_gametest_map *m )
{

	const int step = 1;


	if ( n_game_refresh_is_resize() )
	{
		m->input = true;
		n_game_refresh_off();
	}

	if ( n_win_is_input( VK_UP ) )
	{
		m->input = true;

		m->map.y -= step;
	} else
	if ( n_win_is_input( VK_DOWN ) )
	{
		m->input = true;

		m->map.y += step;
	}
	if ( n_win_is_input( VK_LEFT ) )
	{
		m->input = true;

		m->map.x -= step;
	} else
	if ( n_win_is_input( VK_RIGHT ) )
	{
		m->input = true;

		m->map.x += step;
	}

	if ( n_win_is_input( VK_CONTROL ) )
	{

		m->input = true;

		n_posix_sleep( 200 );


		n_bmp_flush( &game.bmp, game.color );

		m->map.mode++;
		if ( m->map.mode > N_GAME_MAP_MODE_LOOP )
		{
			m->map.mode = N_GAME_MAP_MODE_STOP;
		}

	}


	if ( m->input == false ) { return; }

	m->input = false;


	if ( n_game_refresh_is_off() )
	{

		n_game_refresh_on();

		n_game_map_draw( &m->map, 0, false );

	}


	{

		const n_posix_char *modename[] = {

			n_posix_literal( "Stop"     ),
			n_posix_literal( "Loop X"   ),
			n_posix_literal( "Loop Y"   ),
			n_posix_literal( "Loop All" ),

		};

		n_game_hwndprintf_literal
		(
			"Mode %s : X %ld/%ld : Y %ld/%ld",
			modename[ m->map.mode ],
			m->map.x, m->map.sx,
			m->map.y, m->map.sy
		);

	}


	return;
}

void
n_gametest_map_exit( n_gametest_map *m )
{

	n_game_map_exit( &m->map );


	return;
}

