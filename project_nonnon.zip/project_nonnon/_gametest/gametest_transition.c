// Nonnon Game Test
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/game/game.c"
#include "../nonnon/game/input.c"

#include "../nonnon/game/transition.c"




typedef struct {

	n_bmp        bmp_fg, bmp_bg;

	bool         init, input;

	int          type;
	u32          msec;

} n_gametest_transition;




void
n_gametest_transition_pattern( n_bmp *bmp, s32 sx, s32 sy, u32 fg, u32 bg )
{

	n_bmp_new_fast( bmp, 2,2 );

	n_bmp_flush( bmp, bg );

	n_bmp_ptr_set( bmp, 0,0, fg );

	n_bmp_resizer( bmp, sx,sy, n_bmp_trans, N_BMP_RESIZER_TILE );


	return;
}

void
n_gametest_transition_init( n_gametest_transition *t )
{

	if ( t->init == false )
	{

		t->init = true;

	}


	t->input = true;


	n_bmp_flush( &game.bmp, game.color );


	t->type =    0;
	t->msec = 1000;


	n_game_refresh_on();

	return;
}

void
n_gametest_transition_loop( n_gametest_transition *t )
{

	const int typemin = 0;
	const int typemax = N_GAME_TRANSITION_LAST;
	const int msecmin = 0;
	const int msecmax = 1000 * 10;

	const int off   = 0;
	const int ready = 1;
	const int on    = 2;


	static int running = off;

	//static u32 tick;


	if ( n_game_refresh_is_resize() )
	{

		n_bmp_flush( &game.bmp, game.color );

		n_game_refresh_on();

		return;

	}


	if ( running == off )
	{

		if ( n_win_is_input( VK_UP ) )
		{

			t->input = true;


			if ( t->type < typemax ) { t->type++; }


		} else
		if ( n_win_is_input( VK_DOWN ) )
		{

			t->input = true;


			if ( t->type > typemin ) { t->type--; }

		} else
		if ( n_win_is_input( VK_LEFT ) )
		{

			t->input = true;


			if ( msecmin < t->msec ) { t->msec -= 100; }

		} else
		if ( n_win_is_input( VK_RIGHT ) )
		{

			t->input = true;


			if ( msecmax > t->msec ) { t->msec += 100; }

		} else
		if ( n_win_is_input( VK_SPACE ) )
		{

			running = ready;

		}


		if ( t->input )
		{

			t->input = false;

			n_game_hwndprintf_literal( "Type:%2lu : Msec:%3lu", t->type, t->msec );

			n_posix_sleep( 200 );

		}

	} else
	if ( running == ready )
	{

		static u32 fg,bg;


		running = on;


		n_game_title_literal( "Running" );


		fg = bg;
		bg = n_game_randomcolor();


		n_game_transition_offset_x = 10;
		n_game_transition_offset_y = 10;

		n_gametest_transition_pattern( &t->bmp_fg, game.sx - 20,game.sy - 20, fg,bg );
		n_gametest_transition_pattern( &t->bmp_bg, game.sx - 20,game.sy - 20, bg,fg );


		n_game_transition_circle_x = n_game_random( game.sx );
		n_game_transition_circle_y = n_game_random( game.sy );


		//tick = n_posix_tickcount();

	} else
	if ( running == on )
	{

		// [!] : synchronize to frames

		if ( n_game_refresh_is_on() ) { return; }


		if ( n_game_transition( &game.bmp, &t->bmp_fg, &t->bmp_bg, t->msec, t->type ) )
		{

			running  = off;
			t->input = true;

//n_posix_debug_literal( "%d", (int) n_posix_tickcount() - tick );

		}


		n_game_refresh_on();

	}


	return;
}

void
n_gametest_transition_exit( n_gametest_transition *t )
{

	n_bmp_free( &t->bmp_fg );
	n_bmp_free( &t->bmp_bg );


	return;
}

