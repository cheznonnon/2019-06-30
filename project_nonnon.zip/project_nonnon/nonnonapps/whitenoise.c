// Nonnon White Noise
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




#include "../nonnon/game/sound/directsound.c"
#include "../nonnon/game/sound/waveout.c"
#include "../nonnon/game/timegettime.c"

#include "../nonnon/neutral/wav/all.c"

#include "../nonnon/win32/registry.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_menu.c"
#include "../nonnon/win32/win_systray.c"

#include "../nonnon/project/macro.c"




#ifndef NONNON_APPS

#define N_APPS_OPTION_WHITENOISE n_posix_literal( "-whtenoise" )

#define N_APPS_ICON_OFFSET_WHITENOISE ( 0 )

#endif // #ifndef NONNON_APPS




#define N_WHITENOISE_APPNAME n_posix_literal( "Nonnon White Noise" )




#define N_WHITENOISE_TIMER_SYSTRAY  1
#define N_WHITENOISE_TIMER_INTERVAL 5000



static UINT n_whitenoise_timer_id = 0;




double
n_wav_sample_sandstorm_binaural( double hz, size_t x, size_t offset )
{

	// [!] : human recognition
	//
	//	20Hz to 20,000Hz


	double f = n_posix_minmax( 1, 44100, 1 + n_random_range( hz ) );
	if ( f < ( 44100 - offset ) ) { f += offset; }

	double d = n_wav_sample_sine( f, x );


	return d;
}

void
n_wav_sandstorm_binaural( n_wav *wav, double hz, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	const size_t count = N_WAV_COUNT( wav );


	n_random_shuffle();


	size_t x = 0;
	while( 1 )
	{

		// [!] : brain waves
		//
		//	theta : 4 Hz -  7 Hz
		//	alpha : 8 Hz - 15 Hz

		size_t o = 6;//4 + n_random_range( 12 );

		double d_l = n_wav_sample_sandstorm_binaural( hz, x, 0 );
		double d_r = n_wav_sample_sandstorm_binaural( hz, x, o );

		n_wav_sample_mix( wav, x, d_l, d_r, ratio_l, ratio_r );


		x++;
		if ( x >= count ) { break; }
	}


	return;
}

n_posix_char*
n_whitenoise_startup_commandline( void )
{

	n_posix_char *exe = n_win_exepath_new();

#ifdef NONNON_APPS

	n_posix_char *ret = n_string_path_cat( exe, N_STRING_SPACE, N_APPS_OPTION_WHITENOISE, NULL );
	n_string_free( exe );

#else  // #ifndef NONNON_APPS

	n_posix_char *ret = exe;

#endif // #ifndef NONNON_APPS


	return ret;
}

// internal
void
n_whitenoise_relaunch( HWND hwnd )
{

	n_posix_char *exe = n_whitenoise_startup_commandline();

	n_win_exec( exe, SW_NORMAL );

	n_string_path_free( exe );

	n_win_message_send( hwnd, WM_CLOSE, 0, 0 );


	return;
}

void
n_whitenoise_systray_init( NOTIFYICONDATA *nid, HWND hwnd_parent, bool redraw )
{

	n_posix_char *exe = n_win_exepath_new();

	n_win_systray_init
	(
		nid,
		hwnd_parent,
		N_WHITENOISE_TIMER_SYSTRAY,
		exe,
		N_WHITENOISE_APPNAME,
		redraw
	);

	n_win_systray_icon_change( nid, exe, N_APPS_ICON_OFFSET_WHITENOISE );

	n_string_path_free( exe );


	return;
}

void
n_whitenoise_menu_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HMENU hmenu )
{

	static n_win_menu menu[] = {

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "Register"  ), 1 },
		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "Unegister" ), 1 },
		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---"       ), 1 },
		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "Exit"      ), 1 },
		{ N_WIN_MENU_NONE,  false, false, NULL }

	};


	int ret = n_win_menu_popup_proc( hwnd, msg, wparam, lparam, hmenu, menu, 0 );

	if ( ret == 1 )
	{
//n_posix_debug_literal( " ! " );

		// [x] : Win95 : not supported
		//ShellExecute( hwnd, NULL, n_posix_literal( "shell:startup" ), NULL, NULL, SW_SHOWNORMAL );

		n_posix_char *rval = n_whitenoise_startup_commandline();

		n_project_startup_register( N_WHITENOISE_APPNAME, rval );

		n_string_free( rval );

	} else
	if ( ret == 2 )
	{

		n_project_startup_unregister( N_WHITENOISE_APPNAME );

	} else
	if ( ret == 3 )
	{

		// [!] : Separator

	} else
	if ( ret == 4 )
	{

		n_win_message_send( hwnd, WM_CLOSE, 0,0 );

	}


	return;
}

LRESULT CALLBACK
n_whitenoise_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static NOTIFYICONDATA nid;
	static n_directsound  directsound;
	static n_waveout      waveout;
	static n_wav          wav;
	static bool           is_directsound = false;
	static HMENU          hmenu;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		// [Patch] : old version of n_win_systray_icon_change()
		//
		//	GetDIBits() will fail

		//if ( ( n_sysinfo_version_9x() )&&( wparam == SPI_SETNONCLIENTMETRICS ) )
		//{
		//	n_whitenoise_relaunch( hwnd );
		//} else {
			n_whitenoise_systray_init( &nid, hwnd, true );
		//}

	break;


	case WM_CREATE :


		// Global

		n_win_exedir2curdir();

		n_game_timegettime_init();

		n_win_ime_disable( hwnd );

		if ( n_sysinfo_version_vista_or_later() )
		{
			is_directsound = true;
		}


		// Window

		n_win_init( hwnd, N_WHITENOISE_APPNAME, N_STRING_EMPTY, N_STRING_EMPTY );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		// Display

		hmenu = n_win_menu_popup_hmenu_init();

		ShowWindow( hwnd, SW_HIDE );
		//ShowWindow( hwnd, SW_NORMAL );


		// White Noise

		{

			const double output = 0.10;

			n_wav_zero( &wav );
			n_wav_new( &wav, N_WHITENOISE_TIMER_INTERVAL * 2 );
			n_wav_sandstorm_binaural( &wav, 44100, output, output );


			bool ret = true;

			if ( is_directsound )
			{
				n_directsound_zero( &directsound );
				ret = n_directsound_init( &directsound, hwnd, &wav );
			} else {
				n_waveout_zero( &waveout );
				ret = n_waveout_init( &waveout, &wav );
			}

			if ( ret ) { n_wav_free( &wav ); return -1; }

			if ( is_directsound )
			{
				n_directsound_loop( &directsound );
			} else {
				n_waveout_loop( &waveout );
			}

		}


		// Init

		n_whitenoise_systray_init( &nid, hwnd, true );

		if ( n_whitenoise_timer_id == 0 ) { n_whitenoise_timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, n_whitenoise_timer_id, N_WHITENOISE_TIMER_INTERVAL );

	break;


	case N_WIN_SYSTRAY_MESSAGE :

		if ( wparam != nid.uID ) { break; }

		if ( lparam == WM_RBUTTONUP )
		{
			if ( n_win_is_input( VK_CONTROL ) )
			{
				// [Needed] : to disappear a popup menu
				SetForegroundWindow( hwnd );
				n_win_menu_popup_show( hmenu, hwnd );
			} else {
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
			}
		}

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != n_whitenoise_timer_id ) { break; }

		if ( is_directsound )
		{
			n_directsound_loop( &directsound );
		} else {
			n_waveout_loop( &waveout );
		}

	break;


	case WM_CLOSE :

		n_win_timer_exit( hwnd, n_whitenoise_timer_id );


		if ( is_directsound )
		{

			n_directsound_exit( &directsound );

		} else {

			// [!] : n_waveout_exit() uses WAVEHDR

			n_waveout_exit( &waveout );

		}

		n_wav_free( &wav );


		n_win_systray_exit( &nid );

		n_win_menu_popup_hmenu_exit( hmenu );

		n_game_timegettime_exit();

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_whitenoise_menu_proc( hwnd, msg, wparam, lparam, hmenu );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_whitenoise_wndproc );
}

#endif // #ifndef NONNON_APPS


