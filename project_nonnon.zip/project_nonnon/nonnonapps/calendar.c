// Nonnon Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_APPS_NAME_CALENDAR

#include "../nonnon/project/define_unicode.c"

#include "../nonnon/game/timegettime.c"

#endif // #ifndef N_APPS_NAME_CALENDAR




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_calendar.c"
#include "../nonnon/win32/win_menu.c"
#include "../nonnon/win32/win_popup.c"
#include "../nonnon/win32/win_systray.c"

#include "../nonnon/project/macro.c"




#ifndef N_APPS_NAME_CALENDAR

#define N_APPS_OPTION_CALENDAR   n_posix_literal( "-calendar" )

#endif // #ifndef N_APPS_NAME_CALENDAR




#define N_CALENDAR_SYSTRAY_ID   1
#define N_CALENDAR_TIMER_MSEC   GetDoubleClickTime()
#define N_CALENDAR_EVENT_LAUNCH WM_LBUTTONUP




#define N_CALENDAR_APPNAME n_posix_literal( "Nonnon Calendar" )
#define N_CALENDAR_STICKY  n_posix_literal( "-sticky" )




static bool n_calendar_sticky = false;

static UINT n_calendar_timer_id_main = 0;
static UINT n_calendar_id_tray       = 1;




n_posix_char*
n_calendar_startup_commandline( void )
{

	n_posix_char *exe = n_win_exepath_new();

#ifdef N_APPS_NAME_WHITENOISE

	n_posix_char *ret = n_string_path_cat( exe, N_STRING_SPACE, N_APPS_OPTION_CALENDAR, N_STRING_SPACE, N_CALENDAR_STICKY, NULL );
	n_string_free( exe );

#else  // #ifndef N_APPS_NAME_WHITENOISE

	n_posix_char *ret = exe;

#endif // #ifndef N_APPS_NAME_WHITENOISE


	return ret;
}

// internal
void
n_calendar_relaunch( HWND hwnd )
{

	n_posix_char *exe = n_calendar_startup_commandline();

	n_win_exec( exe, SW_NORMAL );

	n_string_path_free( exe );

	n_win_message_send( hwnd, WM_CLOSE, 0, 0 );


	return;
}

void
n_calendar_resize( HWND hwnd, HWND hcal )
{

	s32 desktop_sx, desktop_sy;
	n_win_desktop_size( &desktop_sx, &desktop_sy );

	s32 desktop = n_posix_min_s32( desktop_sx, desktop_sy );


	s32 size = n_posix_max_s32( 200, (double) desktop * 0.25 );

// [!] : for rc/calendar.multi.ico : this will be 256px
//size = 250;


#ifdef _MSC_VER

	n_win_popup_automove( hwnd, size,size );

	s32 sx = size;
	s32 sy = size;

	if ( n_sysinfo_version_10_or_later() ) { sx += 1; }

#else  // #ifndef _MSC_VER

	n_win_popup_automove( hwnd, size - 2,size - 2 );

	s32 sx = size;
	s32 sy = size;

	// [Patch] : dwm needs more size

	if ( n_project_dwm_is_on() ) { sx += 2; }

#endif // #ifndef _MSC_VER


	n_win_move_simple( hcal, 0,0,sx,sy, false );


	return;
}

// internal
void
n_calendar_option( void )
{

	n_posix_char *cmdline = n_win_commandline_new();


#ifdef N_APPS_NAME_CALENDAR

	// [Needed] : for Nonnon Apps

	n_string_commandline_option( N_APPS_OPTION_CALENDAR, cmdline );

#endif // #ifdef N_APPS_NAME_CALENDAR


	if ( n_string_is_empty( cmdline ) )
	{
		n_calendar_sticky = false;
	} else {
		n_calendar_sticky =  true;
	}


	n_string_path_free( cmdline );


	return;
}

void
n_calendar_menu_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HMENU hmenu )
{

	static n_win_menu menu[] = {

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "Register"  ), 1 },
		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "Unegister" ), 1 },
		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---"       ), 1 },
		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "Exit"      ), 1 },
		{ N_WIN_MENU_NONE,  false, false, NULL }

	};


	int ret = n_win_menu_popup_proc( hwnd, msg, wparam, lparam, hmenu, menu, 0 );

	if ( ret == 1 )
	{
//n_posix_debug_literal( " ! " );

		// [x] : Win95 : not supported
		//ShellExecute( hwnd, NULL, n_posix_literal( "shell:startup" ), NULL, NULL, SW_SHOWNORMAL );

		n_posix_char *rval = n_calendar_startup_commandline();

		n_project_startup_register( N_CALENDAR_APPNAME, rval );

		n_string_free( rval );

	} else
	if ( ret == 2 )
	{

		n_project_startup_unregister( N_CALENDAR_APPNAME );

	} else
	if ( ret == 3 )
	{

		// [!] : Separator

	} else
	if ( ret == 4 )
	{

		n_win_message_send( hwnd, WM_CLOSE, 0,0 );

	}


	return;
}

LRESULT CALLBACK
n_calendar_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_posix_char *iconame    = NULL;
	const  int           iconindex  =    1;


	static NOTIFYICONDATA nid;
	static n_win_calendar cal;

	static bool  onoff = false;
	static HMENU hmenu = NULL;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		// [Patch] : old version of n_win_systray_icon_change()
		//
		//	GetDIBits() will fail

		//if ( ( n_sysinfo_version_9x() )&&( wparam == SPI_SETNONCLIENTMETRICS )&&( n_calendar_sticky ) )
		//{
		//	n_calendar_relaunch( hwnd );
		//} else {
			n_win_systray_icon_change( &nid, iconame, iconindex );
		//}

		n_win_stdfont_init( &cal.hgui, 1 );

	break;


	case WM_NCHITTEST :

		if ( false == n_win_is_hovered( cal.hgui ) ) { return 0; }

	break;


	case WM_CREATE :


		// Global

		n_project_darkmode();

		n_win_exedir2curdir();
		iconame = n_win_exepath_new();

		n_game_timegettime_init();

		n_win_ime_disable( hwnd );


		// Window

		n_win_calendar_init( &cal, hwnd );


		// Style

		n_win_init_literal( hwnd, "", "", "" );

		n_win_popup_autostyle( hwnd, NULL,NULL );

		n_win_topmost( hwnd, true );


		n_win_stdfont_init( &cal.hgui, 1 );


		// Size

		ShowWindow( hwnd, SW_HIDE );
		n_calendar_resize( hwnd, cal.hgui );


		// Display

		hmenu = n_win_menu_popup_hmenu_init();

		n_calendar_option();

		if ( n_calendar_sticky )
		{

			n_win_systray_init( &nid, hwnd, n_calendar_id_tray, N_STRING_EMPTY, N_CALENDAR_APPNAME, true );
			n_win_systray_icon_change( &nid, iconame, iconindex );

			// [!] : magic : prevent blinking

			SetActiveWindow( GetParent( hwnd ) );

		} else {

			n_win_message_send( hwnd, N_WIN_SYSTRAY_MESSAGE, n_calendar_id_tray, N_CALENDAR_EVENT_LAUNCH );

		}

	break;

/*
	case WM_KILLFOCUS :

		if ( n_calendar_sticky )
		{
			ShowWindow( hwnd, SW_HIDE );
		} else {
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;
*/
	case WM_ACTIVATE :

		// [!] : don't use WM_KILLFOCUS

		if ( wparam == WA_INACTIVE )
		{

			if ( n_calendar_timer_id_main == 0 ) { n_calendar_timer_id_main = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, n_calendar_timer_id_main, N_CALENDAR_TIMER_MSEC );

			if ( n_calendar_sticky )
			{
				ShowWindow( hwnd, SW_HIDE );
			} else {
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
			}

		} else {

			//

		}

	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != n_calendar_timer_id_main ) { break; }


		onoff = false;

		n_win_timer_exit( hwnd, n_calendar_timer_id_main );

	break;

	case N_WIN_SYSTRAY_MESSAGE :

		if ( wparam != n_calendar_id_tray ) { break; }


		if ( lparam == N_CALENDAR_EVENT_LAUNCH )
		{

			if ( onoff )
			{
//n_posix_debug_literal( " N_WIN_SYSTRAY_MESSAGE " );

				onoff = false;

			} else {

				onoff = true;

				n_calendar_resize( hwnd, cal.hgui );

				SetFocus( cal.hgui );

				ShowWindow( hwnd, SW_NORMAL );

			}

		} else
		if ( lparam == WM_RBUTTONUP )
		{
			if ( n_win_is_input( VK_CONTROL ) )
			{
				// [Needed] : to disappear a popup menu
				SetForegroundWindow( hwnd );
				n_win_menu_popup_show( hmenu, hwnd );
			} else {
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
			}
		} else
		if ( lparam == WM_LBUTTONDBLCLK )
		{
			onoff = true;
			ShowWindow( hwnd, SW_HIDE );
		}

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_ACTIVATE, WA_INACTIVE,0 );
		}

	break;


	case WM_CLOSE :

		n_win_calendar_exit( &cal, hwnd );

		n_win_timer_exit( hwnd, n_calendar_timer_id_main );

		n_win_stdfont_exit( &cal.hgui, 1 );

		n_win_systray_exit( &nid );

		n_string_path_free( iconame );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_calendar_menu_proc( hwnd, msg, wparam, lparam, hmenu );


	n_win_calendar_proc( hwnd, msg, wparam, lparam, &cal );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef N_APPS_NAME_CALENDAR

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_calendar_wndproc );
}

#endif // #ifndef N_APPS_NAME_CALENDAR


