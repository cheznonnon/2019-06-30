// hunyapiyo3
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"

#include "../nonnon/game/click.c"
//#include "../nonnon/game/hmidiout.c"
#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"
//#include "../nonnon/game/transition.c"


#include "../nonnon/neutral/wav/filter.c"




#define N_HUNYAPIYO3_APPNAME  n_posix_literal( "hunyapiyo3" )

#define N_HUNYAPIYO3_GO       n_posix_literal( "Go!" )
#define N_HUNYAPIYO3_OK       n_posix_literal( "OK"  )


#define N_HUNYAPIYO3_COLOR_BG       n_bmp_rgb(   0, 200, 255 )
#define N_HUNYAPIYO3_COLOR_FRAME    n_bmp_rgb(   0, 150, 200 )
#define N_HUNYAPIYO3_COLOR_FRAME_O  n_bmp_rgb( 255, 255,   0 )
#define N_HUNYAPIYO3_COLOR_FRAME_X  n_bmp_rgb(   1,   1,   1 )
#define N_HUNYAPIYO3_COLOR_MIXER_O  n_bmp_rgb( 255, 255, 255 )
#define N_HUNYAPIYO3_COLOR_MIXER_X  n_bmp_rgb(   1,   1,   1 )
#define N_HUNYAPIYO3_COLOR_TEXT     n_bmp_white
#define N_HUNYAPIYO3_COLOR_CONTOUR  n_bmp_rgb(   0, 150, 200 )
#define N_HUNYAPIYO3_COLOR_SHAFT    n_bmp_rgb(   0, 150, 200 )
#define N_HUNYAPIYO3_COLOR_PROGRESS n_bmp_rgb(   0, 200, 255 )


#define N_HUNYAPIYO3_BMP_ALL ( 5 )
#define N_HUNYAPIYO3_WAV_ALL ( 7 )


#define N_HUNYAPIYO3_SOUND_CLICK       ( 0 )
#define N_HUNYAPIYO3_SOUND_FANFARE     ( 1 )
#define N_HUNYAPIYO3_SOUND_ANSWER_O    ( 2 )
#define N_HUNYAPIYO3_SOUND_ANSWER_X    ( 3 )
#define N_HUNYAPIYO3_SOUND_COUNTDOWN_1 ( 4 )
#define N_HUNYAPIYO3_SOUND_COUNTDOWN_2 ( 5 )
#define N_HUNYAPIYO3_SOUND_COUNTDOWN_3 ( 6 )


#define N_HUNYAPIYO3_RANDOM  ( 4 )
#define N_HUNYAPIYO3_MAP_SX  ( 3 )
#define N_HUNYAPIYO3_MAP_SY  ( 3 )
#define N_HUNYAPIYO3_MAP_ALL ( N_HUNYAPIYO3_MAP_SX * N_HUNYAPIYO3_MAP_SY )


#define N_HUNYAPIYO3_PHASE_CLCK (  0 )
#define N_HUNYAPIYO3_PHASE_STRT (  1 )
#define N_HUNYAPIYO3_PHASE_CD_3 (  2 )
#define N_HUNYAPIYO3_PHASE_CD_2 (  3 )
#define N_HUNYAPIYO3_PHASE_CD_1 (  4 )
#define N_HUNYAPIYO3_PHASE_CD_0 (  5 )
#define N_HUNYAPIYO3_PHASE_INIT (  6 )
#define N_HUNYAPIYO3_PHASE_MAIN (  7 )
#define N_HUNYAPIYO3_PHASE_RSLT (  8 )
#define N_HUNYAPIYO3_PHASE_PERC (  9 )


#define N_HUNYAPIYO3_SHORTTERM_MSEC ( 1000 )
#define N_HUNYAPIYO3_RESULT_MSEC    (  200 )




// Instance

typedef struct {

	s32           zoom;
	s32           sx, sy;
	s32           bar;
	s32           unit;
	s32           countdown_font_size;
	s32           countdown_font_size_unit;
	s32           countdown_font_size_max;
	s32           contour_size;
	s32           message_font_size;
	s32           question_size;

	n_bmp         bmp[ N_HUNYAPIYO3_BMP_ALL ];
	n_bmp         bmp_bg;
	n_bmp         bmp_clickhere;
	n_bmp         bmp_message;
	n_bmp         bmp_question;
	n_bmp         bmp_percent;
	n_bmp         bmp_go;
	n_bmp         bmp_ok;
	n_bmp         bmp_result;

	n_game_sound  snd[ N_HUNYAPIYO3_WAV_ALL ];

	int           map[ N_HUNYAPIYO3_MAP_ALL ];
	int           ret[ N_HUNYAPIYO3_MAP_ALL ];
	int           prv[ N_HUNYAPIYO3_MAP_ALL ];

	int           phase;
	u32           phase_timer;

	bool          go_hover_onoff;
	bool          ok_hover_onoff;

	n_game_click  click_l;
	n_game_click  click_r;

	u32           result_timer;
	int           result_index;

	int           score;
	bool          is_fanfare;

	double        text_jump_coeff;
	u32           text_jump_timer;

	u32           progress;

	s32           px, py;

	bool          is_first;

} n_hunyapiyo3;

static n_hunyapiyo3 hunyapiyo3;




#include "./hunyapiyo3_gdi.c"
#include "./hunyapiyo3_subclass.c"




s32
n_hunyapiyo3_text_jump( n_hunyapiyo3 *p, double pos, double size, u32 speed, double step )
{

	if ( n_game_timer( &p->text_jump_timer, speed ) ) { p->text_jump_coeff += step; }

	return (s32) ( pos - ( size * fabs( sin( 2.0 * M_PI * p->text_jump_coeff ) ) ) );
}

void
n_hunyapiyo3_frame( n_hunyapiyo3 *p, n_bmp *target, s32 x, s32 y, u32 color_frame_outer, u32 color_frame_inner )
{

	n_bmp b; n_bmp_zero( &b ); n_bmp_1st( &b, p->unit, p->unit );

	int u  = n_win_dpi( game.hwnd ) / 96;
	int uu = u * 2;

	n_bmp_box( &b, 0  ,0  ,p->unit   ,p->unit   , color_frame_outer     ); u *= 2; uu = u * 2;
	n_bmp_box( &b, 0+u,0+u,p->unit-uu,p->unit-uu, color_frame_inner     ); u *= 2; uu = u * 2;
	n_bmp_box( &b, 0+u,0+u,p->unit-uu,p->unit-uu, n_bmp_white_invisible );

	n_bmp_transcopy( &b, target, 0,0,p->unit,p->unit, x, y );

	n_bmp_free( &b );


	return;
}

void
n_hunyapiyo3_draw_single( n_hunyapiyo3 *p, n_bmp *target, int index, s32 x, s32 y )
{

	if ( index != -1 )
	{
		n_bmp_transcopy( &p->bmp[ index ], target, 0,0,p->unit,p->unit, x, y );
	} else {
		n_bmp_transcopy( &p->bmp_question, target, 0,0,p->unit,p->unit, x, y );
	}


	return;
}

void
n_hunyapiyo3_reset_panel( n_hunyapiyo3 *p )
{

	// [!] : use 4 panels always


	const bool shuffle = true;


	int neko[ N_HUNYAPIYO3_RANDOM ];

	int i = 0;
	while( 1 )
	{

		neko[ i ] = i;

		i++;
		if ( i >= N_HUNYAPIYO3_RANDOM ) { break; }
	}

	i = 0;
	while( shuffle )
	{

		//if ( 0 == n_random_range( 2 ) )
		{
			int r = n_random_range( N_HUNYAPIYO3_RANDOM );

			int swap  = neko[ i ];
			neko[ i ] = neko[ r ];
			neko[ r ] = swap;
		}

		i++;
		if ( i >= N_HUNYAPIYO3_RANDOM ) { break; }
	}


	int rest = N_HUNYAPIYO3_MAP_ALL;

	int panel_count[ N_HUNYAPIYO3_RANDOM ];

	i = 0;
	while( 1 )
	{

		panel_count[ i ] = 1 + n_random_range( rest - ( N_HUNYAPIYO3_RANDOM - i ) );

		rest -= panel_count[ i ];

		i++;
		if ( i >= N_HUNYAPIYO3_RANDOM ) { break; }

	}

	if ( rest != 0 ) { panel_count[ i - 1 ] += rest; }


	    i = 0;
	int j = 0;
	int k = 0;
	while( 1 )
	{

		p->map[ i ] = neko[ k ];

		i++;
		if ( i >= N_HUNYAPIYO3_MAP_ALL ) { break; }

		j++;
		if ( j >= panel_count[ k ] )
		{
			j = 0;
			k++;
			if ( k >= N_HUNYAPIYO3_RANDOM )
			{
//n_posix_debug_literal( "Never Come" );
				k--;
			}
		}

	}

	i = 0;
	while( shuffle )
	{


		{
			int r = n_random_range( N_HUNYAPIYO3_MAP_ALL );

			int swap    = p->map[ i ];
			p->map[ i ] = p->map[ r ];
			p->map[ r ] = swap;
		}

		i++;
		if ( i >= N_HUNYAPIYO3_MAP_ALL ) { break; }
	}


	return;
}

void
n_hunyapiyo3_reset( n_hunyapiyo3 *p )
{

	p->score = 0;

	p->go_hover_onoff = false;
	p->ok_hover_onoff = false;

	n_hunyapiyo3_gdi_button( &p->bmp_go, p->sx, p->bar, N_HUNYAPIYO3_GO, n_bmp_white_invisible, false );
	n_hunyapiyo3_gdi_button( &p->bmp_ok, p->sx, p->bar, N_HUNYAPIYO3_OK, n_bmp_white_invisible, false );

	n_hunyapiyo3_reset_panel( p );

	int i = 0;
	while( 1 )
	{

		p->ret[ i ] = -1;
		p->prv[ i ] = -2;

		i++;
		if ( i >= N_HUNYAPIYO3_MAP_ALL ) { break; }
	}

	p->is_first = true;


	return;
}




void
n_hunyapiyo3_clickhere( n_hunyapiyo3 *p )
{

	if ( p->is_first )
	{
		p->is_first = false;
		n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );
	}


	s32 sx = N_BMP_SX( &p->bmp_clickhere );
	s32 sy = N_BMP_SY( &p->bmp_clickhere );
	s32  x = n_game_centering( game.sx, sx );
	s32  y = n_game_centering( game.sy, sy );

	y = n_hunyapiyo3_text_jump( p, y, sy / 2, 25, 0.01 );

	n_bmp_fastcopy( &p->bmp_bg, &game.bmp, p->px,p->py,sx,sy, p->px,p->py );

	n_bmp_transcopy( &p->bmp_clickhere, &game.bmp, 0,0,sx,sy, x,y );

	p->px = x;
	p->py = y;


	n_game_refresh_on();
	return;
}

void
n_hunyapiyo3_countdown( n_hunyapiyo3 *p, int number )
{

	if ( p->countdown_font_size < p->countdown_font_size_max )
	{
		n_hunyapiyo3_gdi_countdown( &p->bmp_message, number, p->countdown_font_size, p->contour_size );
	}


	s32 sx = N_BMP_SX( &p->bmp_message );
	s32 sy = N_BMP_SY( &p->bmp_message );
	s32  x = n_game_centering( game.sx, sx );
	s32  y = n_game_centering( game.sy, sy );
//n_bmp_save_literal( &p->bmp_message, "ret.bmp" );

	n_bmp_fastcopy( &p->bmp_bg, &game.bmp, p->px,p->py,sx,sy, p->px,p->py );

	n_bmp_transcopy( &p->bmp_message, &game.bmp, 0,0,sx,sy, x,y );

	p->px = x;
	p->py = y;


	n_game_refresh_on();
	return;
}

void
n_hunyapiyo3_short_term_memory( n_hunyapiyo3 *p )
{

	//n_bmp_flush( &game.bmp, N_HUNYAPIYO3_COLOR_BG );
	n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );


	int x = 0;
	int y = 0;
	while( 1 )
	{

		s32 pxl_x = p->unit * x;
		s32 pxl_y = p->unit * y;

		int map = p->map[ x + ( N_HUNYAPIYO3_MAP_SX * y ) ];

		n_hunyapiyo3_draw_single( p, &game.bmp, map, pxl_x, pxl_y );

		x++;
		if ( x >= N_HUNYAPIYO3_MAP_SX )
		{
			x = 0;
			y++;
			if ( y >= N_HUNYAPIYO3_MAP_SY ) { break; }
		}
	}


	n_game_refresh_on();
	return;
}

bool
n_hunyapiyo3_button( n_hunyapiyo3 *p, bool *onoff, n_bmp *bmp, n_posix_char *str )
{

	bool ret = false;


	s32 cursor_x, cursor_y; n_win_cursor_position_relative( game.hwnd, &cursor_x, &cursor_y );

	if (
		( ( cursor_x >=     0 )&&( cursor_x <   p->sx ) )
		&&
		( ( cursor_y >= p->sy )&&( cursor_y < game.sy ) )
	)
	{

		if ( n_game_click_single( &p->click_l ) )
		{
			ret = true;
		}

		if ( p->click_l.phase == N_GAME_CLICK_PHASE_DOWN )
		{

			if ( (*onoff) )
			{
				n_hunyapiyo3_gdi_button( bmp, p->sx, p->bar, str, n_bmp_rgb( 229,151,0 ),  true );
			}

		} else {

			if ( (*onoff) == false )
			{
				(*onoff) = true;
				n_hunyapiyo3_gdi_button( bmp, p->sx, p->bar, str, n_bmp_rgb( 229,151,0 ), false );
			}

		}

	} else {

		if ( (*onoff) )
		{
			(*onoff) = false;
			n_hunyapiyo3_gdi_button( bmp, p->sx, p->bar, str, n_bmp_white_invisible, false );
		}

	}

	n_bmp_box( &game.bmp, 0,p->sy,p->sx,p->bar, N_HUNYAPIYO3_COLOR_BG );

	n_bmp_transcopy( bmp, &game.bmp, 0,0,p->sx,p->bar, 0,p->sy );


	return ret;
}

void
n_hunyapiyo3_main( n_hunyapiyo3 *p )
{

	//n_bmp_flush( &game.bmp, N_HUNYAPIYO3_COLOR_BG );
	n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );


	bool ret = n_hunyapiyo3_button( p, &p->go_hover_onoff, &p->bmp_go, N_HUNYAPIYO3_GO );
	if ( ret )
	{
		p->phase = N_HUNYAPIYO3_PHASE_RSLT;

		p->result_timer = n_posix_tickcount();
		p->result_index = 0;

		p->text_jump_coeff = 0.0;

		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_CLICK ] );
	}


	int x = 0;
	int y = 0;
	while( 1 )
	{

		s32 pxl_x = p->unit * x;
		s32 pxl_y = p->unit * y;

		s32 cursor_x, cursor_y; n_win_cursor_position_relative( game.hwnd, &cursor_x, &cursor_y );

		int ret_pos = x + ( N_HUNYAPIYO3_MAP_SX * y );

		u32 color_frame = n_bmp_white_invisible;
		if (
			( ( cursor_x >= pxl_x )&&( cursor_x < ( pxl_x + p->unit ) ) )
			&&
			( ( cursor_y >= pxl_y )&&( cursor_y < ( pxl_y + p->unit ) ) )
		)
		{
			color_frame = N_HUNYAPIYO3_COLOR_FRAME_O;
			if ( n_game_click_single( &p->click_l ) )
			{
				p->ret[ ret_pos ]++;
				if ( p->ret[ ret_pos ] >= N_HUNYAPIYO3_RANDOM )
				{
					p->ret[ ret_pos ] = -1;
				}
			} else
			if ( n_game_click_single( &p->click_r ) )
			{
				p->ret[ ret_pos ]--;
				if ( p->ret[ ret_pos ] < -1 )
				{
					p->ret[ ret_pos ] = N_HUNYAPIYO3_RANDOM - 1;
				}
			}

		}

		n_hunyapiyo3_draw_single( p, &game.bmp, p->ret[ ret_pos ], pxl_x, pxl_y );

		n_hunyapiyo3_frame( p, &game.bmp, pxl_x, pxl_y, N_HUNYAPIYO3_COLOR_FRAME, color_frame );


		x++;
		if ( x >= N_HUNYAPIYO3_MAP_SX )
		{
			x = 0;
			y++;
			if ( y >= N_HUNYAPIYO3_MAP_SY ) { break; }
		}
	}


	n_game_refresh_on();
	return;
}

void
n_hunyapiyo3_progressbar( n_hunyapiyo3 *p, double percent_coeff )
{

	n_bmp_box( &game.bmp, 0,p->sy, p->sx,p->bar, n_bmp_black );


	s32 bar = ( p->bar / 6 );
	s32   x = p->unit / 10;
	s32   y = p->sy + n_game_centering( p->bar, bar );
	s32  sx = p->sx - ( x * 2 );
	s32  sy = bar;

	n_bmp_box( &game.bmp, x,y,sx,sy, N_HUNYAPIYO3_COLOR_SHAFT );

	sx = (s32) ( (double) sx * percent_coeff );

	n_bmp_box( &game.bmp, x,y,sx,sy, N_HUNYAPIYO3_COLOR_PROGRESS );


	n_game_refresh_on();
	return;
}

void
n_hunyapiyo3_result( n_hunyapiyo3 *p )
{

	s32 pxl_x = p->unit * ( p->result_index % N_HUNYAPIYO3_MAP_SX );
	s32 pxl_y = p->unit * ( p->result_index / N_HUNYAPIYO3_MAP_SX );

	if ( p->map[ p->result_index ] == p->ret[ p->result_index ] )
	{
		p->score++;
		n_bmp_mixer( &game.bmp, pxl_x,pxl_y,p->unit,p->unit, N_HUNYAPIYO3_COLOR_MIXER_O, 0.25 );
		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_O ] );
		n_hunyapiyo3_frame( p, &game.bmp, pxl_x,pxl_y, N_HUNYAPIYO3_COLOR_FRAME, N_HUNYAPIYO3_COLOR_FRAME_O );
	} else {
		n_bmp_mixer( &game.bmp, pxl_x,pxl_y,p->unit,p->unit, N_HUNYAPIYO3_COLOR_MIXER_X, 0.25 );
		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_X ] );
		n_hunyapiyo3_frame( p, &game.bmp, pxl_x,pxl_y, N_HUNYAPIYO3_COLOR_FRAME, N_HUNYAPIYO3_COLOR_FRAME_X );
	}

	n_game_refresh_on();
	n_game_on_paint();


	if ( p->map[ p->result_index ] == p->ret[ p->result_index ] )
	{
		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_O ] );
	} else {
		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_X ] );
	}

	while( 1 )
	{

		bool ret = false;
		if ( p->map[ p->result_index ] == p->ret[ p->result_index ] )
		{
			ret = n_game_sound_timer( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_O ] );
		} else {
			ret = n_game_sound_timer( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_X ] );
		}

		if ( ret ) { break; }
	}

	p->result_index++;
	if ( p->result_index >= N_HUNYAPIYO3_MAP_ALL )
	{
		p->phase = N_HUNYAPIYO3_PHASE_PERC;

		n_bmp_flush_fastcopy( &game.bmp, &p->bmp_result );

		int percent = (int) ( (double) p->score / N_HUNYAPIYO3_MAP_ALL * 100 );
		n_hunyapiyo3_gdi_percent( &p->bmp_percent, percent, p->message_font_size, p->contour_size );

		if ( p->score == N_HUNYAPIYO3_MAP_ALL ) { p->is_fanfare = true; }
	}

//n_posix_debug_literal( "%d/%d", p->score, N_HUNYAPIYO3_MAP_ALL );


	return;
}

void
n_hunyapiyo3_answer_single( n_hunyapiyo3 *p, s32 x, s32 y )
{

	bool redraw = false;
	u32  color1 = 0;
	u32  color2 = 0;

	int pos = x + ( N_HUNYAPIYO3_MAP_SX * y );
	if ( p->ret[ pos ] == p->map[ pos ] )
	{
		//
	} else
	if ( p->prv[ pos ] == -2 )
	{
		p->prv[ pos ] = p->map[ pos ];

		redraw = true;
		color2 = n_bmp_white_invisible;
	} else
	if ( p->prv[ pos ] == p->ret[ pos ] )
	{
		p->prv[ pos ] = p->map[ pos ];

		redraw = true;
		color2 = n_bmp_white_invisible;
	} else
	if ( p->prv[ pos ] == p->map[ pos ] )
	{
		p->prv[ pos ] = p->ret[ pos ];

		redraw = true;
		color1 = N_HUNYAPIYO3_COLOR_MIXER_X;
		color2 = N_HUNYAPIYO3_COLOR_FRAME_X;
	}

	if ( redraw )
	{
		s32 pxl_x = p->unit * x;
		s32 pxl_y = p->unit * y;

		//n_bmp_box( &p->bmp_result, pxl_x,pxl_y,p->unit,p->unit, N_HUNYAPIYO3_COLOR_BG );
		n_bmp_fastcopy( &p->bmp_bg, &p->bmp_result, pxl_x,pxl_y,p->unit,p->unit, pxl_x,pxl_y );

		n_hunyapiyo3_draw_single( p, &p->bmp_result, p->prv[ pos ], pxl_x, pxl_y );

		if ( color1 != 0 )
		{
			n_bmp_mixer( &p->bmp_result, pxl_x,pxl_y,p->unit,p->unit, color1, 0.25 );
		}

		n_hunyapiyo3_frame( p, &p->bmp_result, pxl_x,pxl_y, N_HUNYAPIYO3_COLOR_FRAME, color2 );

		n_bmp_fastcopy( &p->bmp_result, &game.bmp, pxl_x,pxl_y,p->unit,p->unit, pxl_x,pxl_y );
	}


	return;
}

void
n_hunyapiyo3_percent( n_hunyapiyo3 *p )
{

	s32 cursor_x, cursor_y; n_win_cursor_position_relative( game.hwnd, &cursor_x, &cursor_y );

	if (
		( ( cursor_x >= 0 )&&( cursor_x < p->sx ) )
		&&
		( ( cursor_y >= 0 )&&( cursor_y < p->sy ) )
	)
	{

		if ( n_game_click_single( &p->click_l ) )
		{

			n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_CLICK ] );

			int x = 0;
			int y = 0;
			while( 1 )
			{

				n_hunyapiyo3_answer_single( p, x,y );

				x++;
				if ( x >= N_HUNYAPIYO3_MAP_SX )
				{
					x = 0;
					y++;
					if ( y >= N_HUNYAPIYO3_MAP_SY ) { break; }
				}
			}

		}

	}

	{

		int x = 0;
		int y = 0;
		while( 1 )
		{

			s32 pxl_x = p->unit * x;
			s32 pxl_y = p->unit * y;

			if (
				( ( cursor_x >= pxl_x )&&( cursor_x < ( pxl_x + p->unit ) ) )
				&&
				( ( cursor_y >= pxl_y )&&( cursor_y < ( pxl_y + p->unit ) ) )
			)
			{
				if ( n_game_click_single( &p->click_r ) )
				{
					n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_CLICK ] );
					n_hunyapiyo3_answer_single( p, x,y );
				}
			}

			x++;
			if ( x >= N_HUNYAPIYO3_MAP_SX )
			{
				x = 0;
				y++;
				if ( y >= N_HUNYAPIYO3_MAP_SY ) { break; }
			}
		}

	}


	s32 sx = N_BMP_SX( &p->bmp_percent );
	s32 sy = N_BMP_SY( &p->bmp_percent );

	n_bmp_fastcopy( &p->bmp_result, &game.bmp, p->px,p->py,sx,sy, p->px,p->py );


	bool ret = n_hunyapiyo3_button( p, &p->ok_hover_onoff, &p->bmp_ok, N_HUNYAPIYO3_OK );
	if ( ret )
	{

		hunyapiyo3.phase = N_HUNYAPIYO3_PHASE_CLCK;

		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_CLICK ] );

		//n_bmp_flush( &game.bmp, N_HUNYAPIYO3_COLOR_BG );
		n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

		n_game_refresh_on();
		return;

	}


	s32  x = n_game_centering( game.sx, sx );
	s32  y = n_game_centering( game.sy, sy );
//n_bmp_save_literal( &p->bmp_message, "ret.bmp" );

	if (
		( ( cursor_x >= x )&&( cursor_x < ( x + sx ) ) )
		&&
		( ( cursor_y >= y )&&( cursor_y < ( y + sy ) ) )
	)
	{

		//

	} else {

		y = n_hunyapiyo3_text_jump( p, y, sy / 2, 25, 0.01 );

		n_bmp_transcopy( &p->bmp_percent, &game.bmp, 0,0,sx,sy, x,y );

	}

	p->px = x;
	p->py = y;


	n_game_refresh_on();
	return;
}




#define n_hunyapiyo3_zero( p ) n_memory_zero( p, sizeof( n_hunyapiyo3 ) )

void
n_hunyapiyo3_init( n_hunyapiyo3 *p )
{

	// Global

	n_bmp_safemode = false;

	s32 desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );
	s32 desktop_size = n_posix_min_s32( desktop_sx, desktop_sy );


	// Metrics

	p->unit = (s32) n_posix_max_double( (double) 48 * 1.33, (double) desktop_size * 0.1 );
	p->sx   = p->unit * N_HUNYAPIYO3_MAP_SX;
	p->sy   = p->unit * N_HUNYAPIYO3_MAP_SY;

	s32 control_size; n_win_stdsize( game.hwnd, &control_size, NULL, NULL );
	p->bar = control_size;

//n_posix_debug_literal( " %d ", p->unit );
	p->contour_size             = p->unit / 30;
	p->countdown_font_size_unit = p->unit /  5;
	p->countdown_font_size_max  = (s32) ( (double) p->sx * 0.8 );
	p->message_font_size        = p->sx   /  6;

	p->countdown_font_size_unit /= n_posix_max( 1, n_win_dpi( game.hwnd ) / 75 );


	// System

	n_game_title( N_HUNYAPIYO3_APPNAME );

	game.sx    = p->sx;
	game.sy    = p->sy + p->bar;
	game.fps   = 30;
	game.color = N_HUNYAPIYO3_COLOR_BG;

	n_win_set_patch( game.hwnd, &game.sx, &game.sy, 16, 16 );

	n_game_window_fixed();


	//n_hmidiout_init();


	n_hunyapiyo3_subclass_init( p );


	n_game_dwm_onoff();


	// Resources

	n_game_rc_load_bmp_literal( &p->bmp[ 0 ], "HUNYAPIYO3_BMP_0" );
	n_game_rc_load_bmp_literal( &p->bmp[ 1 ], "HUNYAPIYO3_BMP_1" );
	n_game_rc_load_bmp_literal( &p->bmp[ 2 ], "HUNYAPIYO3_BMP_2" );
	n_game_rc_load_bmp_literal( &p->bmp[ 3 ], "HUNYAPIYO3_BMP_3" );
	n_game_rc_load_bmp_literal( &p->bmp[ 4 ], "HUNYAPIYO3_BMP_4" );

	p->zoom = (s32) ( (double) p->unit * 0.66 ) / N_BMP_SX( &p->bmp[ 0 ] );

	n_bmp_scaler_big( &p->bmp[ 0 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 1 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 2 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 3 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 4 ], p->zoom );

	p->question_size = N_BMP_SX( &p->bmp[ 0 ] );

	{

		int i = 0;
		while( 1 )
		{

			n_bmp_resizer( &p->bmp[ i ], p->unit,p->unit, n_bmp_black, N_BMP_RESIZER_CENTER );

			i++;
			if ( i >= N_HUNYAPIYO3_BMP_ALL ) { break; }
		}

		n_hunyapiyo3_gdi_question( &p->bmp_question, p->unit, p->question_size, p->contour_size );

	}


	n_game_sound_bulk_zero( p->snd, N_HUNYAPIYO3_WAV_ALL );

	n_game_sound_init_literal( &p->snd[ 0 ], game.hwnd, "HUNYAPIYO3_WAV_0" );
	n_game_sound_init_literal( &p->snd[ 1 ], game.hwnd, "HUNYAPIYO3_WAV_1" );
	n_game_sound_init_literal( &p->snd[ 2 ], game.hwnd, "HUNYAPIYO3_WAV_2" );
	n_game_sound_init_literal( &p->snd[ 3 ], game.hwnd, "HUNYAPIYO3_WAV_3" );
	n_game_sound_init_literal( &p->snd[ 4 ], game.hwnd, "HUNYAPIYO3_WAV_4" );
	n_game_sound_init_literal( &p->snd[ 5 ], game.hwnd, "HUNYAPIYO3_WAV_5" );
	n_game_sound_init_literal( &p->snd[ 6 ], game.hwnd, "HUNYAPIYO3_WAV_6" );

	{

		int i = 0;
		while( 1 )
		{

			n_wav_smoother( &p->snd[ i ].wav );

			i++;
			if ( i >= N_HUNYAPIYO3_WAV_ALL ) { break; }
		}

	}


	// Init

//n_game_title_literal( "Click!" );

	n_game_click_init( &p->click_l, VK_LBUTTON );
	n_game_click_init( &p->click_r, VK_RBUTTON );


	n_hunyapiyo3_gdi_background( &p->bmp_bg );
	n_hunyapiyo3_gdi_clickhere( &p->bmp_clickhere, p->message_font_size, p->contour_size );


	n_bmp_new( &p->bmp_result, game.sx, game.sy );


	p->is_first = true;


	return;
}

void
n_hunyapiyo3_exit( n_hunyapiyo3 *p )
{

	{

		int i = 0;
		while( 1 )
		{

			n_bmp_free( &p->bmp[ i ] );

			i++;
			if ( i >= N_HUNYAPIYO3_BMP_ALL ) { break; }
		}

	}

	{

		int i = 0;
		while( 1 )
		{

			n_game_sound_exit( &p->snd[ i ] );

			i++;
			if ( i >= N_HUNYAPIYO3_WAV_ALL ) { break; }
		}

	}


	n_bmp_free( &p->bmp_bg        );
	n_bmp_free( &p->bmp_message   );
	n_bmp_free( &p->bmp_clickhere );
	n_bmp_free( &p->bmp_percent   );
	n_bmp_free( &p->bmp_go        );
	n_bmp_free( &p->bmp_ok        );
	n_bmp_free( &p->bmp_result    );


	n_hunyapiyo3_subclass_exit( p );


	//n_hmidiout_exit();


	return;
}

void
n_hunyapiyo3_loop( n_hunyapiyo3 *p )
{

	if ( n_game_refresh_is_on() ) { return; }


	if ( p->phase == N_HUNYAPIYO3_PHASE_CLCK )
	{

		n_hunyapiyo3_clickhere( p );

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_STRT )
	{
//n_game_hwndprintf_literal( "3" );

		p->phase       = N_HUNYAPIYO3_PHASE_CD_3;
		p->phase_timer = n_posix_tickcount();

		//n_hmidiout_all( 0, 55, N_HMIDIOUT_PANPOT_LEFT , 72, 80 );
		//n_hmidiout_all( 1, 55, N_HMIDIOUT_PANPOT_RIGHT, 72, 80 );
		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_COUNTDOWN_3 ] );

		//n_bmp_flush( &game.bmp, N_HUNYAPIYO3_COLOR_BG );
		n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_CD_3 )
	{

		if ( n_game_timer( &p->phase_timer, 1000 ) )
		{
//n_game_hwndprintf_literal( "2" );

			p->phase       = N_HUNYAPIYO3_PHASE_CD_2;
			p->phase_timer = n_posix_tickcount();

			p->countdown_font_size = 0;

			//n_hmidiout_all( 0, 55, N_HMIDIOUT_PANPOT_LEFT , 74, 100 );
			//n_hmidiout_all( 1, 55, N_HMIDIOUT_PANPOT_RIGHT, 74, 100 );
			n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_COUNTDOWN_2 ] );

			//n_bmp_flush( &game.bmp, N_HUNYAPIYO3_COLOR_BG );
			n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

		} else {

			p->countdown_font_size += p->countdown_font_size_unit;
			n_hunyapiyo3_countdown( p, 3 );

		}

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_CD_2 )
	{

		if ( n_game_timer( &p->phase_timer, 1000 ) )
		{
//n_game_hwndprintf_literal( "1" );

			p->phase       = N_HUNYAPIYO3_PHASE_CD_1;
			p->phase_timer = n_posix_tickcount();

			p->countdown_font_size = 0;

			//n_hmidiout_all( 0, 55, N_HMIDIOUT_PANPOT_LEFT , 76, 120 );
			//n_hmidiout_all( 1, 55, N_HMIDIOUT_PANPOT_RIGHT, 76, 120 );
			n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_COUNTDOWN_1 ] );

			//n_bmp_flush( &game.bmp, N_HUNYAPIYO3_COLOR_BG );
			n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

		} else {

			p->countdown_font_size += p->countdown_font_size_unit;
			n_hunyapiyo3_countdown( p, 2 );

		}

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_CD_1 )
	{

		if ( n_game_timer( &p->phase_timer, 1000 ) )
		{
//n_game_hwndprintf( N_HUNYAPIYO3_APPNAME );

			p->phase       = N_HUNYAPIYO3_PHASE_CD_0;
			p->phase_timer = n_posix_tickcount();

			p->countdown_font_size = 0;

			//n_hmidiout_all( 0, 55, N_HMIDIOUT_PANPOT_LEFT , 0, 0 );
			//n_hmidiout_all( 1, 55, N_HMIDIOUT_PANPOT_RIGHT, 0, 0 );

			//n_bmp_flush( &game.bmp, N_HUNYAPIYO3_COLOR_BG );
			n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

		} else {

			p->countdown_font_size += p->countdown_font_size_unit;
			n_hunyapiyo3_countdown( p, 1 );

		}

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_CD_0 )
	{

		n_hunyapiyo3_short_term_memory( p );

		p->phase       = N_HUNYAPIYO3_PHASE_INIT;
		p->phase_timer = n_posix_tickcount();
		p->progress    = p->phase_timer;

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_INIT )
	{

		if ( n_game_timer( &p->phase_timer, N_HUNYAPIYO3_SHORTTERM_MSEC ) )
		{
			p->phase = N_HUNYAPIYO3_PHASE_MAIN;
		}

//n_game_hwndprintf_literal( " %f ", (double) ( n_posix_tickcount() - p->progress ) / N_HUNYAPIYO3_SHORTTERM_MSEC );
		n_hunyapiyo3_progressbar( p, (double) ( n_posix_tickcount() - p->progress ) / N_HUNYAPIYO3_SHORTTERM_MSEC );

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_MAIN )
	{

		n_hunyapiyo3_main( p );

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_RSLT )
	{

		if ( n_game_timer( &p->result_timer, N_HUNYAPIYO3_RESULT_MSEC ) )
		{
			n_hunyapiyo3_result( p );
		}

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_PERC )
	{

		if ( p->is_fanfare )
		{
			p->is_fanfare = false;
			n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_FANFARE ] );
		}

		n_hunyapiyo3_percent( p );

	} // else


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_hunyapiyo3_zero( &hunyapiyo3 );
	n_hunyapiyo3_init( &hunyapiyo3 );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_hunyapiyo3_exit( &hunyapiyo3 );
		n_hunyapiyo3_init( &hunyapiyo3 );
		n_game_reset();
	}

	n_hunyapiyo3_loop( &hunyapiyo3 );


	return;
}

void
n_game_exit( void )
{

	n_hunyapiyo3_exit( &hunyapiyo3 );


	return;
}

#endif // #ifndef N_GAMECONSOLE

