// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_progressbar.c"

#include "../nonnon/project/macro.c"




#define N_PAINT_COLORHISTORY_OFFSET (  2 )
#define N_PAINT_COLORHISTORY_COUNT  ( 10 )




static HWND n_paint_colorhistory_hgui [ N_PAINT_COLORHISTORY_COUNT ];
static u32  n_paint_colorhistory_color[ N_PAINT_COLORHISTORY_COUNT ];




void
n_paint_colorhistory_init( void )
{

	// Reserved

	n_paint_colorhistory_color[ 0 ] = n_bmp_black;
	n_paint_colorhistory_color[ 1 ] = n_bmp_white;


	int i = N_PAINT_COLORHISTORY_OFFSET;
	while( 1 )
	{

		n_paint_colorhistory_color[ i ] = n_bmp_rgb( 0,200,255 );


		i++;
		if ( i >= N_PAINT_COLORHISTORY_COUNT ) { break; }
	}


	return;
}

void
n_paint_colorhistory_add( u32 color )
{

	int i = N_PAINT_COLORHISTORY_OFFSET;
	while( 1 )
	{

		if ( n_paint_colorhistory_color[ i ] == color ) { return; }


		i++;
		if ( i >= N_PAINT_COLORHISTORY_COUNT ) { break; }
	}


	memmove
	(
		&n_paint_colorhistory_color[ N_PAINT_COLORHISTORY_OFFSET + 1 ],
		&n_paint_colorhistory_color[ N_PAINT_COLORHISTORY_OFFSET + 0 ],
		sizeof(u32) * ( N_PAINT_COLORHISTORY_COUNT - 1 - N_PAINT_COLORHISTORY_OFFSET )
	);

	n_paint_colorhistory_color[ N_PAINT_COLORHISTORY_OFFSET ] = color;


	return;
}

// internal
void
n_paint_colorhistory_move( HWND hwnd )
{

	s32 ctl;

	n_win_stdsize( hwnd, &ctl, NULL, NULL );


	s32 csx = ctl * N_PAINT_COLORHISTORY_COUNT;
	s32 csy = ctl * N_PAINT_COLORHISTORY_COUNT;

	s32 patch_csx = csx;
	s32 patch_csy = csy;

	n_win_set_patch( hwnd, &patch_csx, &patch_csy, 12, 12 );

	n_win_set( hwnd, NULL, patch_csx,patch_csy, N_WIN_SET_CENTERING );


	int i = 0;
	while( 1 )
	{

		HWND hgui;
		n_win_gui_literal( hwnd, CANVAS, "", &hgui );
		n_paint_colorhistory_hgui[ i ] = hgui;


		n_win_style_add( hgui, SS_NOTIFY );


		n_win_move_simple( hgui, 0, i * ctl, csx,ctl, false );


		int a = n_bmp_a( n_paint_colorhistory_color[ i ] );
		int r = n_bmp_r( n_paint_colorhistory_color[ i ] );
		int g = n_bmp_g( n_paint_colorhistory_color[ i ] );
		int b = n_bmp_b( n_paint_colorhistory_color[ i ] );

		n_win_hwndprintf_literal( hgui, "%d / %d / %d / %d", a, r, g, b );


		i++;
		if ( i >= N_PAINT_COLORHISTORY_COUNT ) { break; }
	}


	return;
}

LRESULT CALLBACK
n_paint_colorhistory_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );


		// Window

		n_win_init_literal( hwnd, "History", "NONNON_PAINT_3_0_COLOR", "" );


		// Style

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		// Size

		n_paint_colorhistory_move( hwnd );

		n_win_stdfont_init( n_paint_colorhistory_hgui, N_PAINT_COLORHISTORY_COUNT );


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, false );
		EnableWindow( hwnd_main, false );

	break;


	case WM_COMMAND :
	{

		if ( STN_CLICKED != HIWORD( wparam ) ) { break; }


		int i = 0;
		while( 1 )
		{

			if ( (HWND) lparam == n_paint_colorhistory_hgui[ i ] )
			{

				extern n_win_colorpicker cp;


				u32 c = n_paint_colorhistory_color[ i ];
				int a = n_bmp_a( c );
				int r = n_bmp_r( c );
				int g = n_bmp_g( c );
				int b = n_bmp_b( c );

				nwclr_refresh( &cp, a,r,g,b );

//n_posix_debug_literal( "%d %d %d", r,g,b );

				break;

			}


			i++;
			if ( i >= N_PAINT_COLORHISTORY_COUNT ) { break; }
		}

		n_win_message_send( hwnd, WM_CLOSE, 0,0 );

	}
	break;


	case WM_CLOSE :

		n_win_stdfont_exit( n_paint_colorhistory_hgui, N_PAINT_COLORHISTORY_COUNT );


		EnableWindow( hwnd_tool, true );
		EnableWindow( hwnd_main, true );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{

		const int edge =   0;
		const int pc   = 100;

		int i = 0;
		while( 1 )
		{

			HWND hgui  = n_paint_colorhistory_hgui[ i ];
			u32  color = n_bmp_pal2rgb( n_paint_colorhistory_color[ i ] );

			n_win_progressbar_proc( hwnd, msg, wparam, lparam, hgui, edge, pc, color, color );


			i++;
			if ( i >= N_PAINT_COLORHISTORY_COUNT ) { break; }
		}

	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

