// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#define UNICODE


#include "../../nonnon/win32/win.c"
#include "../../nonnon/win32/wintab.c"

#include "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_wintab wt;


	switch( msg ) {


	case WM_CREATE :

		ZeroMemory( &wt, sizeof( n_wintab ) );
		n_wintab_init( &wt, hwnd );


		n_win_init_literal( hwnd, "Nonnon", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 512,256, N_WIN_SET_CENTERING );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_MOUSEMOVE :

		// [!]
		//
		//	zero : wt.lc.lcStatus
		//	zero : n_wintab_tps_stat_get( &wt )
		//	zero : wt.packet.pkButtons
		//	-1   : wt.lc.lcBtnDnMask

		n_win_hwndprintf_literal
		(
			hwnd,
			"Pressure %d/%d: Type %d : Pos %d %d",
			n_wintab_pressure_get( &wt ),
			n_wintab_pressure_max( &wt ),
			n_wintab_pen_type_get( &wt ),
			(int) wt.packet.pkX,
			(int) wt.packet.pkY
		);

	break;


	case WM_CLOSE :

		n_wintab_exit( &wt );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_wintab_packet_proc( hwnd, msg, wparam, lparam, &wt );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

