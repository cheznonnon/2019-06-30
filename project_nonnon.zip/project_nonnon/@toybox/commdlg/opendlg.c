



#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include <windows.h>
#include <commdlg.h>




int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	char str[ PATH_MAX ]; ZeroMemory( str, PATH_MAX * sizeof( char ) );


    	OPENFILENAME ofn; ZeroMemory( &ofn, sizeof( OPENFILENAME ) );

	ofn.lStructSize = sizeof( OPENFILENAME );
	ofn.hwndOwner   = NULL;
	ofn.lpstrFilter = "";
	ofn.lpstrFile   = str;
	ofn.nMaxFile    = PATH_MAX;
	ofn.Flags       = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
	ofn.lpstrDefExt = "";
	ofn.lpstrTitle  = "Nonnon Test";
 

	GetOpenFileName( &ofn );

//MessageBoxA( NULL, str, "DEBUG", 0 );


	return 0;
}

